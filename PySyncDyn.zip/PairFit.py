import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import least_squares
from numba import njit, prange
from functools import partial
from tqdm import tqdm
import time
import logging
import datetime
from multiprocessing import Pool, cpu_count
import configparser
import argparse
import sys


# Initialize the global logger
logger = logging.getLogger(__name__) 

# Define the relative gamma values for different nuclei
RELATIVE_GAMMA = {
    '15N': 0.1014,
    '13C': 0.2515
}

def get_nucleus_from_config(config_file):
    """Get and validate nucleus type from config file"""
    config = configparser.ConfigParser(inline_comment_prefixes=(';', '#'))
    try:
        config.read(config_file)
        nucleus = config.get('General', 'Nucleus', fallback=None)
        if nucleus:
            # Clean up the nucleus string
            nucleus = str(nucleus).strip().strip("'").strip('"')
            clean_nucleus = nucleus.upper()
            if clean_nucleus not in RELATIVE_GAMMA:
                if clean_nucleus.startswith('C') and '13' in clean_nucleus:
                    clean_nucleus = '13C'
                elif clean_nucleus.startswith('N') and '15' in clean_nucleus:
                    clean_nucleus = '15N'
            
            if clean_nucleus in RELATIVE_GAMMA:
                return RELATIVE_GAMMA[clean_nucleus]
            else:
                print(f"Error: Unsupported nucleus {nucleus}. Must be either '15N' or '13C'.")
                sys.exit(1)
        else:
            print("Error: Nucleus not specified in the [General] section of UserInput.ini")
            sys.exit(1)
    except Exception as e:
        print(f"Error reading configuration: {e}")
        sys.exit(1)


 
parser = argparse.ArgumentParser(description="Read Excel Assignments and Generate Pair Fitting Results.")
parser.add_argument('-i', '--userinput', type=str, default='UserInput.ini', help='Path to the UserInput.ini file.')
args = parser.parse_args()
relativeGamma = get_nucleus_from_config(args.userinput)


def load_excel_assignments(file_path):
    """
    Load assignments from an Excel file into a dictionary of DataFrames.
    """
    logger.info(f"Attempting to load Excel file: {file_path}")
    if not os.path.exists(file_path):
        logger.error(f"The file {file_path} does not exist.")
        raise FileNotFoundError(f"The file {file_path} does not exist.")

    xls = pd.ExcelFile(file_path)
    assignments = {}

    logger.info(f"Excel file '{file_path}' contains sheets: {xls.sheet_names}")
    for sheet in xls.sheet_names:
        logger.debug(f"Processing sheet: {sheet}")
        assignment_name = sheet[len('Assign_'):] if sheet.startswith('Assign_') else sheet
        df = pd.read_excel(xls, sheet_name=sheet, index_col=0)

        required_cols = {'Vcpmg', 'R2Eff', 'eR2Eff', 'B0'}
        missing_cols = required_cols - set(df.columns)
        if missing_cols:
            logger.warning(f"Missing columns {missing_cols} in sheet '{sheet}'.")

        for col in ['Vcpmg', 'R2Eff', 'eR2Eff', 'B0']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')

        assignments[assignment_name] = df.reset_index(drop=True)
        logger.debug(f"Loaded DataFrame for '{assignment_name}' with shape {df.shape}")

    logger.info(f"Successfully loaded {len(assignments)} assignments from '{file_path}'.")
    return assignments

@njit
def carver_richards_pair_numba(params, vcp, gammaB0, R20_indices, df_ids):
    """
    Numba-accelerated Carver-Richards model for pair fitting.
    """
    kab = params[0]
    kba = params[1]
    Dw_ppm_df1 = params[2]
    Dw_ppm_df2 = params[3]
    n_R20 = params.size - 4
    R20_array = params[4:]
    n = vcp.size
    R2Eff_sim = np.empty(n)

    for i in prange(n):
        Dw_ppm = Dw_ppm_df1 if df_ids[i] == 0 else Dw_ppm_df2
        R20 = R20_array[R20_indices[i]]
        kex = kab + kba
        Dw = 2 * np.pi * Dw_ppm * gammaB0[i]
        psi = kex**2 - Dw**2
        zeta = -2 * Dw * (kba - kab)
        sqrt_term = np.sqrt(psi**2 + zeta**2)

        etap = 0.0
        etan = 0.0
        if vcp[i] != 0:
            etap = np.sqrt((psi + sqrt_term)) / (2 * np.sqrt(2) * vcp[i])
            etan = np.sqrt((-psi + sqrt_term)) / (2 * np.sqrt(2) * vcp[i])

        Dp = 0.5 * (1 + (psi + 2 * Dw**2) / sqrt_term) if sqrt_term != 0 else 0.5
        Dn = 0.5 * (-1 + (psi + 2 * Dw**2) / sqrt_term) if sqrt_term != 0 else -0.5

        argument = Dp * np.cosh(etap) - Dn * np.cos(etan)
        if argument < 1.0:
            argument = 1.0000001  # To avoid invalid arccosh

        R2Eff_sim[i] = R20 + kex / 2 - vcp[i] * np.arccosh(argument)

    return R2Eff_sim

def fit_carver_richards_least_squares_pair(params_initial_guess, params_bounds, vcp, gammaB0, R2Eff_exp, eR2Eff_exp, R20_indices, df_ids):
    """
    Fit the Carver-Richards model to experimental R2Eff data using least squares.
    """
    logger.debug("Starting least squares fitting.")
    def residuals(params):
        R2Eff_sim = carver_richards_pair_numba(params, vcp, gammaB0, R20_indices, df_ids)
        return (R2Eff_sim - R2Eff_exp) / eR2Eff_exp

    # Increase max_nfev (number of function evaluations) and adjust other parameters
    try:
        result = least_squares(
            residuals,
            params_initial_guess,
            method='trf',  # Trust Region Reflective algorithm
            bounds=params_bounds,
            jac='2-point',
            verbose=0,
            max_nfev=10000 * len(params_initial_guess),  # Increased from 1000
            xtol=1e-8,  # Relaxed tolerance (was 1e-12)
            ftol=1e-8,  # Relaxed tolerance (was 1e-12)
            gtol=1e-8,  # Relaxed tolerance (was 1e-12)
            tr_solver='exact',  # Use exact trust-region solution
            loss='soft_l1'  # Add robust loss function to handle outliers
        )
    except Exception as e:
        logger.error(f"Initial fitting attempt failed: {e}")
        # Try again with different method if first attempt fails
        try:
            result = least_squares(
                residuals,
                params_initial_guess,
                method='lm',  # Switch to Levenberg-Marquardt algorithm
                jac='2-point',
                verbose=0,
                max_nfev=10000 * len(params_initial_guess),
                ftol=1e-8,
                xtol=1e-8,
                gtol=1e-8
            )
        except Exception as e2:
            logger.error(f"Second fitting attempt failed: {e2}")
            return None, None, None, None, None

    if result.success:
        logger.info(f"Fitting successful: {result.message}")
    else:
        logger.warning(f"Fitting completed but may not be optimal: {result.message}")

    try:
        J = result.jac
        residuals_arr = result.fun
        dof = len(R2Eff_exp) - len(result.x)
        residual_variance = np.sum(residuals_arr**2) / dof
        JTJ = J.T @ J
        epsilon = 1e-6  # Increased from 1e-8
        JTJ += epsilon * np.eye(JTJ.shape[0])
        covariance_matrix = np.linalg.inv(JTJ) * residual_variance
        parameter_errors = np.sqrt(np.diag(covariance_matrix))
        logger.debug("Computed covariance matrix and parameter errors.")
    except np.linalg.LinAlgError as e:
        logger.warning(f"Could not compute covariance matrix due to LinAlgError: {e}")
        parameter_errors = np.full_like(result.x, np.nan)
    except Exception as e:
        logger.warning(f"Could not compute covariance matrix. {e}")
        parameter_errors = np.full_like(result.x, np.nan)

    chi2 = np.sum(result.fun ** 2)
    chi2_reduced = chi2 / dof if dof != 0 else np.nan
    logger.debug(f"Chi²: {chi2}, Reduced Chi²: {chi2_reduced}")

    return result.x, parameter_errors, result, chi2, chi2_reduced

def generate_pairs(assignments):
    """
    Generate all unique residue pairs from the assignments.
    """
    Residues = list(assignments.keys())
    residuePairs = [(Residues[i], Residues[j]) for i in range(len(Residues)) for j in range(i+1, len(Residues))]
    logger.info(f"Generated {len(residuePairs)} unique residue pairs.")
    return residuePairs


def prepare_pair_data(assignments, pair):
    """
    Prepare and clean data for a given pair of assignments.
    Replaces zero eR2Eff values with the minimum non-zero error for the same B0.
    """
    assignment1, assignment2 = pair
    logger.info(f"Preparing data for Pair: {pair}")
    df1 = assignments[assignment1]
    df2 = assignments[assignment2]
    logger.debug(f"Data Shape - {assignment1}: {df1.shape}")
    logger.debug(f"Data Shape - {assignment2}: {df2.shape}")

    if 'B0' not in df1.columns or 'B0' not in df2.columns:
        logger.error(f"One of the assignments in pair {pair} is missing 'B0' column.")
        return None, None, None, None, None

    # Create copies of the dataframes
    df1_clean = df1.copy()
    df2_clean = df2.copy()

    # Function to replace zero errors with minimum non-zero error for same B0
    def replace_zero_errors(df):
        for b0 in df['B0'].unique():
            mask_b0 = df['B0'] == b0
            non_zero_errors = df.loc[mask_b0 & (df['eR2Eff'] > 0), 'eR2Eff']
            
            if len(non_zero_errors) > 0:
                min_error = non_zero_errors.min()
                df.loc[mask_b0 & (df['eR2Eff'] == 0), 'eR2Eff'] = min_error
                zero_count = sum(mask_b0 & (df['eR2Eff'] == 0))
                if zero_count > 0:
                    logger.info(f"B0 {b0}: Replaced {zero_count} zero errors with minimum error {min_error:.6f}")
            else:
                # If no non-zero errors for this B0, use global minimum non-zero error
                global_non_zero_min = df[df['eR2Eff'] > 0]['eR2Eff'].min()
                if pd.notnull(global_non_zero_min):
                    df.loc[mask_b0 & (df['eR2Eff'] == 0), 'eR2Eff'] = global_non_zero_min
                    zero_count = sum(mask_b0 & (df['eR2Eff'] == 0))
                    if zero_count > 0:
                        logger.info(f"B0 {b0}: No non-zero errors found, used global minimum {global_non_zero_min:.6f} for {zero_count} points")
                else:
                    logger.warning(f"No non-zero errors found in entire dataset for {df.name if hasattr(df, 'name') else 'dataset'}")
        return df

    # Replace zero errors in both dataframes
    df1_clean = replace_zero_errors(df1_clean)
    df2_clean = replace_zero_errors(df2_clean)

    # Now only drop rows where other required columns are NaN
    df1_clean = df1_clean.dropna(subset=['Vcpmg', 'R2Eff', 'B0'])
    df2_clean = df2_clean.dropna(subset=['Vcpmg', 'R2Eff', 'B0'])

    if df1_clean.empty:
        logger.warning(f"Assignment '{assignment1}' has no valid data after cleaning.")
        return None, None, None, None, None

    if df2_clean.empty:
        logger.warning(f"Assignment '{assignment2}' has no valid data after cleaning.")
        return None, None, None, None, None

    df1_clean['PairID'] = 0
    df2_clean['PairID'] = 1

    combined_df = pd.concat([df1_clean, df2_clean], ignore_index=True)
    logger.debug(f"Combined Data Shape: {combined_df.shape}")

    unique_B0 = sorted(combined_df['B0'].unique())
    n_B0 = len(unique_B0)
    logger.info(f"Found {n_B0} unique B0 values: {unique_B0}")

    R20_mapping = {}
    for pair_id in [0, 1]:
        for idx, b0 in enumerate(unique_B0):
            R20_mapping[(b0, pair_id)] = pair_id * n_B0 + idx

    logger.debug("R20 Mapping:")
    for key, value in R20_mapping.items():
        logger.debug(f"  {key}: R20 index {value}")

    R20_indices = combined_df.apply(lambda row: R20_mapping.get((row['B0'], row['PairID']), -1), axis=1).values
    if -1 in R20_indices:
        logger.warning("Some (B0, PairID) combinations were not mapped to R20 indices.")

    df_ids = combined_df['PairID'].values
    combined_df['gammaB0'] = combined_df['B0'].astype(int) * relativeGamma
    logger.debug("Calculated gammaB0 for all data points.")

    return combined_df, unique_B0, R20_mapping, R20_indices, df_ids


def perform_pair_fit(combined_df, unique_B0, R20_mapping, R20_indices, df_ids):
    """
    Perform the fitting process for a single pair.
    
    Parameters:
    - combined_df (DataFrame): Combined and cleaned DataFrame for the pair.
    - unique_B0 (list): Sorted list of unique B0 values.
    - R20_mapping (dict): Mapping from (B0, PairID) to R20 index.
    - R20_indices (np.array): Array of R20 indices for data points.
    - df_ids (np.array): Array of DataFrame IDs for data points.
    
    Returns:
    - fit_data (dict): Dictionary containing fitted parameters and their errors.
    - fitted_params (np.array): Optimized parameters.
    - parameter_errors (np.array): Errors of the optimized parameters.
    - chi2 (float): Chi-squared value.
    - chi2_reduced (float): Reduced Chi-squared value.
    - unique_B0 (list): Sorted list of unique B0 values.
    """
    logger.info("Starting fitting process for the pair.")
    vcp = combined_df['Vcpmg'].values
    gammaB0 = combined_df['gammaB0'].values
    R2Eff_exp = combined_df['R2Eff'].values
    eR2Eff_exp = combined_df['eR2Eff'].values

    logger.debug(f"Number of data points for fitting: {len(vcp)}")

    # Initial parameter guesses
    initial_guess_shared = np.array([2000.0, 200.0])  # kab, kba
    initial_guess_Dw = np.array([1.0, 1.0])  # Dw_ppm_df1, Dw_ppm_df2
    initial_guess_R20 = np.full(len(unique_B0) * 2, combined_df['R2Eff'].mean())
    params_initial_guess = np.concatenate([initial_guess_shared, initial_guess_Dw, initial_guess_R20])

    # Parameter bounds
    bounds_shared_lower = [0, 0]
    bounds_shared_upper = [10000, 10000]
    bounds_Dw_lower = [0, 0]
    bounds_Dw_upper = [20, 20]
    bounds_R20_lower = [0] * (len(unique_B0) * 2)
    bounds_R20_upper = [1000] * (len(unique_B0) * 2)
    params_bounds = (bounds_shared_lower + bounds_Dw_lower + bounds_R20_lower,
                     bounds_shared_upper + bounds_Dw_upper + bounds_R20_upper)

    logger.debug(f"Initial parameter guesses: {params_initial_guess}")
    logger.debug(f"Parameter bounds set. Lower bounds: {params_bounds[0]}")
    logger.debug(f"Upper bounds: {params_bounds[1]}")

    logger.info("Initiating least squares fitting...")
    try:
        fitted_params, parameter_errors, fit_result, chi2, chi2_reduced = fit_carver_richards_least_squares_pair(
            params_initial_guess,
            params_bounds,
            vcp,
            gammaB0,
            R2Eff_exp,
            eR2Eff_exp,
            R20_indices,
            df_ids
        )
    except Exception as e:
        logger.error(f"Exception during fitting: {e}")
        return None

    if fit_result is None or not fit_result.success:
        logger.error("Fitting failed or result is None.")
        return None

    # Extract fitted parameters
    kab, kba, Dw_ppm_df1, Dw_ppm_df2 = fitted_params[:4]
    R20_df1 = fitted_params[4:4 + len(unique_B0)]
    R20_df2 = fitted_params[4 + len(unique_B0):]
    R20_err_df1 = parameter_errors[4:4 + len(unique_B0)]
    R20_err_df2 = parameter_errors[4 + len(unique_B0):]

    logger.info("\nFitted Parameters:")
    logger.info(f"kab = {kab:.4f} ± {parameter_errors[0]:.4f}")
    logger.info(f"kba = {kba:.4f} ± {parameter_errors[1]:.4f}")
    logger.info(f"Dw_ppm_df1 = {Dw_ppm_df1:.4f} ± {parameter_errors[2]:.4f}")
    logger.info(f"Dw_ppm_df2 = {Dw_ppm_df2:.4f} ± {parameter_errors[3]:.4f}")
    for idx, b0 in enumerate(unique_B0):
        logger.info(f"R20_{b0}_df1 = {R20_df1[idx]:.4f} ± {R20_err_df1[idx]:.4f}")
    for idx, b0 in enumerate(unique_B0):
        logger.info(f"R20_{b0}_df2 = {R20_df2[idx]:.4f} ± {R20_err_df2[idx]:.4f}")
    logger.info(f"Chi² = {chi2:.2f}")
    logger.info(f"Reduced Chi² = {chi2_reduced:.2f}\n")

    # Calculate kex and p values
    kex = kab + kba
    kex_err = np.sqrt(parameter_errors[0]**2 + parameter_errors[1]**2)

    # Calculate p = min(kab, kba) / kex
    p1 = kab / kex if kex != 0 else np.nan
    p2 = kba / kex if kex != 0 else np.nan
    p = min(p1, p2) if not np.isnan(p1) and not np.isnan(p2) else np.nan

    # Calculate p_err based on which p was selected
    if p == p1:
        p_err = np.sqrt(
            (parameter_errors[0] / kex)**2 +
            (kab * parameter_errors[1] / kex**2)**2
        )
    elif p == p2:
        p_err = np.sqrt(
            (parameter_errors[1] / kex)**2 +
            (kba * parameter_errors[0] / kex**2)**2
        )
    else:
        p_err = np.nan  # In case kex is zero

    # Add Pe and Pe_err to fit_data
    fit_data = {
        'kab': kab,
        'kab_err': parameter_errors[0],
        'kba': kba,
        'kba_err': parameter_errors[1],
        'Dw_ppm_df1': Dw_ppm_df1,
        'Dw_ppm_df1_err': parameter_errors[2],
        'Dw_ppm_df2': Dw_ppm_df2,
        'Dw_ppm_df2_err': parameter_errors[3],
        'Pe': p,                # Population
        'Pe_err': p_err,        # Error in Population
        'Chi2': chi2,
        'Chi2_reduced': chi2_reduced
    }
    for idx, b0 in enumerate(unique_B0):
        fit_data[f'R20_{b0}_df1'] = R20_df1[idx]
    for idx, b0 in enumerate(unique_B0):
        fit_data[f'R20_{b0}_df2'] = R20_df2[idx]
    logger.info(f"Calculated population (Pe) = {p:.4f} ± {p_err:.4f}")

    # Add errors for R20
    for idx, b0 in enumerate(unique_B0):
        fit_data[f'R20_{b0}_df1_err'] = R20_err_df1[idx]
    for idx, b0 in enumerate(unique_B0):
        fit_data[f'R20_{b0}_df2_err'] = R20_err_df2[idx]

    logger.debug("Fitting data prepared successfully.")
    return fit_data, fitted_params, parameter_errors, chi2, chi2_reduced, unique_B0


def plot_results(
    pair,
    combined_df,
    unique_B0,
    R20_mapping,
    fitted_params,
    parameter_errors,
    chi2,
    chi2_reduced,
    save_plot,
    save_dir,
    save_plot_type,
    Chi2Plot=False,
    Chi2_PlotVar=None,
    R20_indices=None,
    df_ids=None
):
    """
    Plot the fitting results for a given pair.

    Parameters:
    - pair (tuple): A tuple containing two assignment names.
    - combined_df (DataFrame): Combined and cleaned DataFrame for the pair.
    - unique_B0 (list): Sorted list of unique B0 values.
    - R20_mapping (dict): Mapping from (B0, PairID) to R20 index.
    - fitted_params (np.array): Optimized parameters.
    - parameter_errors (np.array): Errors of the optimized parameters.
    - chi2 (float): Chi-squared value.
    - chi2_reduced (float): Reduced Chi-squared value.
    - save_plot (bool): Whether to save the plot.
    - save_dir (str): Directory to save plots.
    - save_plot_type (str): Type of plot to save ('png' or 'pdf').
    - Chi2Plot (bool): Whether to include a Chi-squared plot.
    - Chi2_PlotVar (str): Variable name for which to plot Chi-squared.
    - R20_indices (np.array): Array of R20 indices for data points.
    - df_ids (np.array): Array of DataFrame IDs for data points.
    """
    logger.info(f"Starting plot for Pair: {pair}")

    # Set the font to Arial
    plt.rcParams['font.family'] = 'Arial'
    # Editable in illustrator
    plt.rcParams['pdf.fonttype'] = 42

    # Check if R20_indices and df_ids are provided
    if R20_indices is None or df_ids is None:
        logger.error("R20_indices or df_ids are not provided to plot_results.")
        return

    # Initialize plot with separate axes for legend and annotations
    if Chi2Plot:
        # 1x3 grid: main plot, Chi² plot, legend & text box
        fig, axes = plt.subplots(1, 3, figsize=(14, 5), gridspec_kw={'width_ratios': [3, 2, 2]})
        ax_fit, ax_chi2, ax_legend = axes
        logger.debug("Initialized 1x3 subplot grid for plotting.")
    else:
        # 1x2 grid: main plot, legend & text box
        fig, axes = plt.subplots(1, 2, figsize=(10, 5), gridspec_kw={'width_ratios': [3, 2]})
        ax_fit, ax_legend = axes
        logger.debug("Initialized 1x2 subplot grid for plotting.")

    sns.set(style="whitegrid")

    # Define color palettes
    palette = sns.color_palette("hsv", len(unique_B0))

    # Extract fitted parameters
    kab, kba, Dw_ppm_df1, Dw_ppm_df2 = fitted_params[:4]
    R20_df1 = fitted_params[4:4 + len(unique_B0)]
    R20_df2 = fitted_params[4 + len(unique_B0):]
    R20_err_df1 = parameter_errors[4:4 + len(unique_B0)]
    R20_err_df2 = parameter_errors[4 + len(unique_B0):]

    # Calculate kex and p values
    kex = kab + kba
    kex_err = np.sqrt(parameter_errors[0]**2 + parameter_errors[1]**2)

    # Calculate p = min(kab/kex, kba/kex)
    p1 = kab / kex if kex != 0 else np.nan
    p2 = kba / kex if kex != 0 else np.nan
    p = min(p1, p2) if not np.isnan(p1) and not np.isnan(p2) else np.nan

    # Calculate p_err based on which p was selected
    if p == p1:
        p_err = np.sqrt(
            (parameter_errors[0] / kex)**2 +
            (kab * parameter_errors[1] / kex**2)**2
        )
    elif p == p2:
        p_err = np.sqrt(
            (parameter_errors[1] / kex)**2 +
            (kba * parameter_errors[0] / kex**2)**2
        )
    else:
        p_err = np.nan  # In case kex is zero

    logger.debug(f"Calculated kex: {kex:.4f} ± {kex_err:.4f}")
    logger.debug(f"Calculated p: {p:.4f} ± {p_err:.4f}")

    # Plot data and fits for each B0
    for idx, b0 in enumerate(unique_B0):
        color = palette[idx]
        df1_subset = combined_df[(combined_df['B0'] == b0) & (combined_df['PairID'] == 0)]
        df2_subset = combined_df[(combined_df['B0'] == b0) & (combined_df['PairID'] == 1)]

        # Plot experimental data for assignment1
        ax_fit.errorbar(
            df1_subset['Vcpmg'],
            df1_subset['R2Eff'],
            yerr=2 * df1_subset['eR2Eff'],
            fmt='o',
            color=color,
            ecolor=color,
            capsize=5,
            label=f'{pair[0]} - B0={b0} (Data)',
            markeredgecolor='black',
            markersize=6,
            alpha=0.7
        )
        logger.debug(f"Plotted data points for {pair[0]} at B0={b0}.")

        # Plot experimental data for assignment2
        ax_fit.errorbar(
            df2_subset['Vcpmg'],
            df2_subset['R2Eff'],
            yerr=2 * df2_subset['eR2Eff'],
            fmt='s',
            color=color,
            ecolor=color,
            capsize=5,
            label=f'{pair[1]} - B0={b0} (Data)',
            markeredgecolor='black',
            markersize=6,
            alpha=0.7
        )
        logger.debug(f"Plotted data points for {pair[1]} at B0={b0}.")

        # Generate Vcpmg values for fitting curves
        vcp_fit = np.linspace(combined_df['Vcpmg'].min(), combined_df['Vcpmg'].max(), 200)
        gammaB0_fit = np.full(len(vcp_fit), int(b0) * relativeGamma)

        # Simulate R2Eff for assignment1
        R20_idx_df1 = R20_mapping.get((b0, 0), -1)
        if R20_idx_df1 != -1:
            R2Eff_fit_df1 = carver_richards_pair_numba(
                fitted_params,
                vcp_fit,
                gammaB0_fit,
                np.full(len(vcp_fit), R20_idx_df1),
                np.full(len(vcp_fit), 0)
            )
            ax_fit.plot(
                vcp_fit,
                R2Eff_fit_df1,
                color=color,
                linestyle='--',
                linewidth=2,
                label=f'{pair[0]} - B0={b0} (Fit)'
            )
            logger.debug(f"Plotted fit curve for {pair[0]} at B0={b0}.")

        # Simulate R2Eff for assignment2
        R20_idx_df2 = R20_mapping.get((b0, 1), -1)
        if R20_idx_df2 != -1:
            R2Eff_fit_df2 = carver_richards_pair_numba(
                fitted_params,
                vcp_fit,
                gammaB0_fit,
                np.full(len(vcp_fit), R20_idx_df2),
                np.full(len(vcp_fit), 1)
            )
            ax_fit.plot(
                vcp_fit,
                R2Eff_fit_df2,
                color=color,
                linestyle=':',
                linewidth=2,
                label=f'{pair[1]} - B0={b0} (Fit)'
            )
            logger.debug(f"Plotted fit curve for {pair[1]} at B0={b0}.")

    # Remove duplicate labels
    handles, labels = ax_fit.get_legend_handles_labels()
    unique = dict(zip(labels, handles))

    # Create legend in the dedicated axis
    ax_legend.legend(unique.values(), unique.keys(), fontsize=9, title_fontsize=12, loc='upper left')
    ax_legend.axis('off')  # Hide the legend axis
    logger.debug("Created legend for the plot.")

    # Annotate plot with fitted parameters, kex, p, Chi² in the legend axis
    annotation_text = '\n'.join([
        f"kab = {kab:.4f} ± {parameter_errors[0]:.4f}",
        f"kba = {kba:.4f} ± {parameter_errors[1]:.4f}",
        f"kex = {kex:.4f} ± {kex_err:.4f}",
        f"p = {p:.4f} ± {p_err:.4f}",
        f"Dw_ppm_{pair[0]} = {Dw_ppm_df1:.4f} ± {parameter_errors[2]:.4f}",
        f"Dw_ppm_{pair[1]} = {Dw_ppm_df2:.4f} ± {parameter_errors[3]:.4f}"
    ])
    for idx, b0 in enumerate(unique_B0):
        annotation_text += f"\nR20_{b0}_{pair[0]} = {R20_df1[idx]:.4f} ± {R20_err_df1[idx]:.4f}"
    for idx, b0 in enumerate(unique_B0):
        annotation_text += f"\nR20_{b0}_{pair[1]} = {R20_df2[idx]:.4f} ± {R20_err_df2[idx]:.4f}"
    annotation_text += f"\nChi² = {chi2:.2f}"
    annotation_text += f"\nReduced Chi² = {chi2_reduced:.2f}"

    ax_legend.text(
        0.05, 0.05, annotation_text,  # Lower y-coordinate for textbox
        transform=ax_legend.transAxes,
        fontsize=10,
        verticalalignment='bottom',
        bbox=dict(boxstyle="round", facecolor="white", alpha=0.8)
    )
    logger.debug("Annotated plot with fitted parameters and Chi² values.")

    # Set labels and title for the main plot
    ax_fit.set_xlabel(r'$\nu_{cpmg}$', fontsize=14)
    ax_fit.set_ylabel(r'$R_{2}^{Eff} (S^{-1})$', fontsize=14)
    ax_fit.set_title(f'Pair Fit: {pair[0]} & {pair[1]}', fontsize=16)
    logger.debug("Set plot labels and title.")

    # Handle Chi² Plot if required
    if Chi2Plot and Chi2_PlotVar:
        logger.info(f"Handling Chi² plot for parameter '{Chi2_PlotVar}'...")
        param_names_all = ['kab', 'kba', 'Dw_ppm_df1', 'Dw_ppm_df2'] + \
                          [f'R20_{b0}_df1' for b0 in unique_B0] + \
                          [f'R20_{b0}_df2' for b0 in unique_B0]
        if Chi2_PlotVar not in param_names_all:
            logger.error(f"Chi2_PlotVar must be one of {param_names_all}, got '{Chi2_PlotVar}'. Skipping Chi2 plot.")
        else:
            param_idx = param_names_all.index(Chi2_PlotVar)
            fitted_value = fitted_params[param_idx]
            param_error = parameter_errors[param_idx]

            # Handle case where parameter error is zero or NaN
            if np.isnan(param_error) or param_error == 0:
                # Set a default parameter error
                param_error = 0.1 * abs(fitted_value) if fitted_value != 0 else 0.1
                logger.warning(f"Parameter error for {Chi2_PlotVar} is zero or NaN, setting default error to {param_error}")

            # Ensure positive parameter values
            param_min = max(1e-8, fitted_value - 5 * param_error)
            param_max = fitted_value + 5 * param_error

            # Ensure param_min < param_max
            if param_min >= param_max:
                delta = abs(fitted_value) * 0.1 if fitted_value != 0 else 0.1
                param_min = max(1e-8, fitted_value - delta)
                param_max = fitted_value + delta
                logger.warning(f"Adjusted parameter range for {Chi2_PlotVar} to [{param_min}, {param_max}]")

            param_values = np.linspace(param_min, param_max, 100)
            logger.debug(f"Parameter '{Chi2_PlotVar}' range for Chi² plot: {param_min:.4f} to {param_max:.4f}")

            chi2_values = []
            for val in param_values:
                params_fixed = np.array(fitted_params)
                params_fixed[param_idx] = val
                try:
                    R2Eff_sim = carver_richards_pair_numba(
                        params_fixed,
                        combined_df['Vcpmg'].values,
                        combined_df['gammaB0'].values,
                        R20_indices,
                        df_ids
                    )
                    residuals = (R2Eff_sim - combined_df['R2Eff'].values) / combined_df['eR2Eff'].values
                    chi2_val = np.sum(residuals**2)
                    chi2_values.append(chi2_val)
                except Exception as e:
                    logger.error(f"Error computing Chi² for parameter value {val}: {e}")
                    chi2_values.append(np.nan)  # Append NaN for error

            # Remove NaN values
            chi2_values_clean = [chi2 for chi2 in chi2_values if not np.isnan(chi2)]
            if not chi2_values_clean:
                logger.error("All Chi² values are NaN. Cannot plot Chi² map.")
            else:
                # Normalize Chi²
                chi2_min = min(chi2_values_clean)
                chi2_normalized = [chi2 - chi2_min for chi2 in chi2_values]

                # Find the parameter value with minimum Chi²
                min_index = np.nanargmin(chi2_values)
                min_param_value = param_values[min_index]
                min_chi2 = chi2_normalized[min_index]

                logger.info("Plotting Chi² map...")
                try:
                    # Plot Chi²
                    ax_chi2.plot(param_values, chi2_normalized, color='blue')
                    ax_chi2.set_xlabel(f'{Chi2_PlotVar}', fontsize=14)
                    ax_chi2.set_ylabel('Normalized χ²', fontsize=14)
                    ax_chi2.set_title(f'χ² Map vs {Chi2_PlotVar}\nPair: {pair[0]} & {pair[1]}', fontsize=16)
                    ax_chi2.axvline(fitted_value, color='red', linestyle='--', label='Fitted Value')

                    # Annotate minimum Chi²
                    ax_chi2.plot(min_param_value, min_chi2, 'ro')
                    ax_chi2.annotate(
                        f"Min χ²\n{Chi2_PlotVar}={min_param_value:.4f}\nχ²={min_chi2:.2f}",
                        xy=(min_param_value, min_chi2),
                        xytext=(min_param_value + 0.05 * (param_max - param_min), min_chi2 + max(chi2_normalized)*0.05),
                        arrowprops=dict(facecolor='black', arrowstyle="->"),
                        fontsize=10,
                        bbox=dict(boxstyle="round,pad=0.3", edgecolor="black", facecolor="white", alpha=0.8)
                    )

                    ax_chi2.legend()
                    logger.debug("Chi² map plotted successfully.")
                except Exception as e:
                    logger.error(f"Error plotting Chi² map for Pair {pair}: {e}")

    plt.tight_layout()
    logger.debug("Applied tight layout to the plot.")

    # Save or display the plot
    if save_plot:
        try:
            os.makedirs(save_dir, exist_ok=True)
            safe_assignment1 = "".join([c if c.isalnum() else "_" for c in pair[0]])
            safe_assignment2 = "".join([c if c.isalnum() else "_" for c in pair[1]])
            # Determine file extension based on save_plot_type
            if save_plot_type.lower() == 'png':
                plot_filename = f'PairFit_{safe_assignment1}_{safe_assignment2}.png'
            elif save_plot_type.lower() == 'pdf':
                plot_filename = f'PairFit_{safe_assignment1}_{safe_assignment2}.pdf'
            else:
                logger.error(f"Unsupported save_plot_type '{save_plot_type}'. Defaulting to PNG.")
                plot_filename = f'PairFit_{safe_assignment1}_{safe_assignment2}.png'
            plot_path = os.path.join(save_dir, plot_filename)
            plt.savefig(plot_path, dpi=300)
            logger.info(f"Plot saved to {plot_path}")
            plt.close(fig)
            logger.debug("Closed the figure after saving.")
        except Exception as e:
            logger.error(f"Error saving plot for Pair {pair}: {e}")
    else:
        plt.close(fig)
        logger.debug("Closed the figure without saving.")

def process_pair(args):
    """
    Wrapper function to process a single pair. Suitable for multiprocessing.

    Parameters:
    - args (tuple): Contains all necessary arguments for processing a pair.

    Returns:
    - result (dict or None): Fit data dictionary if successful, else None.
    """
    pair, assignments, save_plot, save_dir, save_plot_type, Chi2Plot, Chi2_PlotVar = args
    logger.info(f"Processing pair: {pair}")
    combined_df, unique_B0, R20_mapping, R20_indices, df_ids = prepare_pair_data(assignments, pair)
    if combined_df is None:
        logger.warning(f"Data preparation failed for pair: {pair}")
        return None

    fit_results = perform_pair_fit(combined_df, unique_B0, R20_mapping, R20_indices, df_ids)
    if fit_results is None:
        logger.warning(f"Fitting failed for pair: {pair}")
        return None

    fit_data, fitted_params, parameter_errors, chi2, chi2_reduced, unique_B0 = fit_results

    # **Set 'Pair' within the process_pair function**
    fit_data['Pair'] = f"{pair[0]}_{pair[1]}"
    logger.debug(f"Assigned 'Pair' as {fit_data['Pair']}.")

    if save_plot:
        logger.info(f"Plotting results for pair: {pair}")
        plot_results(
            pair, 
            combined_df, 
            unique_B0, 
            R20_mapping, 
            fitted_params, 
            parameter_errors,
            chi2,
            chi2_reduced,
            save_plot, 
            save_dir, 
            save_plot_type, 
            Chi2Plot, 
            Chi2_PlotVar,
            R20_indices=R20_indices,
            df_ids=df_ids
        )
    else:
        logger.debug("Plot saving is disabled.")

    logger.info(f"Completed processing for pair: {pair}")
    return fit_data
 
def PairFitAndSave(excel_file, save_plot=False, save_plot_type='png', 
                  Chi2Plot=False, Chi2_PlotVar=None, ComputeCores=1):
    """
    Load assignments from an Excel file, perform pair fitting for all pairs, and save the results.

    Parameters:
    - excel_file (str): Path to the Excel file containing assignment sheets.
    - save_plot (bool): Whether to save the plots.
    - save_plot_type (str): Type of plot to save ('png' or 'pdf').
    - Chi2Plot (bool): Whether to include a Chi-squared plot.
    - Chi2_PlotVar (str): Variable name for which to plot Chi-squared.
    - ComputeCores (int): Number of CPU cores to use for parallel processing.
    
    Returns:
    - df_results (DataFrame): DataFrame containing fitting results for all pairs.
    """
    global logger  # Declare global before any use of logger

    # Set 'save_dir' to the directory where 'excel_file' exists
    save_dir = os.path.dirname(os.path.abspath(excel_file))
    
    # Ensure 'save_dir' exists before setting up the logger
    try:
        os.makedirs(save_dir, exist_ok=True)
        logger.info(f"Ensured that save directory '{save_dir}' exists.")
    except Exception as e:
        logger.error(f"Failed to create save directory '{save_dir}': {e}")
        return pd.DataFrame()  # Return empty DataFrame on failure

    # Set up logging inside the function, so that 'save_dir' is available
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)  # Set to DEBUG to capture all logs

    # Create handlers
    fh = logging.FileHandler(os.path.join(save_dir, f'script_{datetime.datetime.now().strftime("%y%m%d_%H%M%S")}.log'))
    fh.setLevel(logging.DEBUG)  # Capture all logs in the file

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)  # Capture INFO and above in the console

    # Create formatters and add them to handlers
    formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)

    # Clear existing handlers and add the new handlers
    if logger.hasHandlers():
        logger.handlers.clear()
    logger.addHandler(fh)
    logger.addHandler(ch)

    # add Nuclus and RelativeGamma to logger 
    logger.info(f"RelativeGamma: {relativeGamma}")

    logger.info("Starting PairFitAndSave process...")

    # Load assignments from the Excel file
    try:
        assignments = load_excel_assignments(excel_file)
    except Exception as e:
        logger.error(f"Failed to load assignments: {e}")
        return pd.DataFrame()  # Return empty DataFrame on failure

    # Clean up assignments if necessary
    assignments = cleanup_assignments(assignments)

    residuePairs = generate_pairs(assignments)
    results = []
    start_time = time.time()

    # Prepare arguments for multiprocessing
    args_list = [
        (pair, assignments, save_plot, save_dir, save_plot_type, Chi2Plot, Chi2_PlotVar)
        for pair in residuePairs
    ]

    # Determine the number of cores to use
    available_cores = cpu_count()
    if ComputeCores < 1:
        ComputeCores = 1
    elif ComputeCores > available_cores:
        ComputeCores = available_cores
    logger.info(f"Using {ComputeCores} out of {available_cores} available CPU cores for processing.")

    # Initialize multiprocessing pool
    try:
        with Pool(processes=ComputeCores) as pool:
            logger.info("Initialized multiprocessing pool.")
            for result in tqdm(pool.imap_unordered(process_pair, args_list), total=len(args_list), desc="Processing Pairs"):
                if result:
                    results.append(result)
                    logger.debug(f"Appended results for a pair. Total successful pairs: {len(results)}")
    except Exception as e:
        logger.error(f"Error during multiprocessing: {e}")

    total_time = time.time() - start_time
    logger.info(f"Pair fitting completed in {total_time:.2f} seconds.")

    df_results = pd.DataFrame(results)
    if df_results.empty:
        logger.warning("No fitting results were obtained.")
    else:
        # Verify that 'Pair' exists and is correctly formatted
        if 'Pair' not in df_results.columns:
            logger.error("'Pair' column is missing from the results.")
        else:
            # Check if all 'Pair' entries contain exactly one '_'
            invalid_pairs = df_results['Pair'].str.count('_') != 1
            if invalid_pairs.any():
                logger.error("Some 'Pair' entries do not contain exactly one '_'. Please check the data.")
                # Optionally, handle or remove invalid pairs
                df_results = df_results[~invalid_pairs]
                logger.info(f"Removed {invalid_pairs.sum()} invalid pair entries.")

            # Proceed only if all 'Pair' entries are valid
            if not df_results.empty:
                # Split 'Pair' into two columns
                try:
                    df_results[['Assignment1', 'Assignment2']] = df_results['Pair'].str.split('_', expand=True)
                    logger.debug("Split 'Pair' column into 'Assignment1' and 'Assignment2'.")
                except ValueError as ve:
                    logger.error(f"Error splitting 'Pair' column: {ve}")
                    # Handle the error as needed, e.g., skip splitting or assign default values

                # Reorder columns to have 'Assignment1' and 'Assignment2' as the first two columns
                cols = df_results.columns.tolist()
                # Remove 'Assignment1' and 'Assignment2' from their current positions if they exist
                for col in ['Assignment1', 'Assignment2']:
                    if col in cols:
                        cols.remove(col)
                # Remove 'Pair' column
                if 'Pair' in cols:
                    cols.remove('Pair')
                # Now set the new column order
                cols = ['Assignment1', 'Assignment2'] + cols
                df_results = df_results[cols]
                logger.info("Reordered columns in the results DataFrame.")

            # Save df_results as an Excel file in the same directory where plots are saved with higher precision
            results_filename = 'pair_fit_results.xlsx'
            results_filepath = os.path.join(save_dir, results_filename)
            try:
                with pd.ExcelWriter(results_filepath, engine='openpyxl') as writer:
                    df_results.to_excel(writer, index=False, sheet_name='Results')
                    workbook = writer.book
                    worksheet = writer.sheets['Results']
                    # Set number format for all float columns to display 6 decimal places
                    for idx, column in enumerate(df_results.columns, 1):
                        if pd.api.types.is_float_dtype(df_results[column]):
                            for cell in worksheet.iter_cols(min_col=idx, max_col=idx, min_row=2):
                                for c in cell:
                                    c.number_format = '0.000000'
                logger.info(f"Results saved to {results_filepath} with increased decimal precision.")
            except Exception as e:
                logger.error(f"Error saving results to Excel file: {e}")

    return df_results

def cleanup_assignments(assignments):
    """
    Clean up the assignments dictionary by ensuring all DataFrames have the same number of rows.
    Any assignment with a shorter length than the maximum length is removed.
    """
    logger.info("Starting cleanup of assignments to ensure consistent DataFrame lengths.")
    # Determine the length of each assignment
    lengths = {key: len(df) for key, df in assignments.items()}
    max_length = max(lengths.values())
    logger.info(f"Maximum assignment length found: {max_length} rows.")

    # Identify and remove assignments with fewer rows than the maximum length
    cleaned_assignments = {key: df for key, df in assignments.items() if len(df) == max_length}
    removed_assignments = set(assignments.keys()) - set(cleaned_assignments.keys())

    if removed_assignments:
        logger.info(f"Removed assignments with fewer than {max_length} rows: {removed_assignments}")
    else:
        logger.info("All assignments have the same number of rows. No assignments were removed.")

    logger.debug(f"Number of assignments after cleanup: {len(cleaned_assignments)}")
    return cleaned_assignments

def compute_rsquare_chi2(excel_file, results_file):
    """
    Compute R-squared and Chi-squared values for each pair and update the results Excel file.
    """
    global logger
    
    # Set 'save_dir' to the directory where 'excel_file' exists
    save_dir = os.path.dirname(os.path.abspath(excel_file))
    
    # Ensure 'save_dir' exists
    try:
        os.makedirs(save_dir, exist_ok=True)
        logger.info(f"Ensured that save directory '{save_dir}' exists.")
    except Exception as e:
        logger.error(f"Failed to create save directory '{save_dir}': {e}")
        return
    
    # Load assignments from Excel file
    try:
        assignments = load_excel_assignments(excel_file)
        logger.info(f"Successfully loaded assignments from {excel_file}")
    except Exception as e:
        logger.error(f"Error loading assignments: {e}")
        return
    
    # Clean up assignments to match those used in the fitting function
    assignments = cleanup_assignments(assignments)
    assignment_keys = list(assignments.keys())
    logger.info(f"Available assignments after cleanup: {assignment_keys}")
    
    # Read the results file
    results_filepath = os.path.join(save_dir, results_file)
    try:
        df_results = pd.read_excel(results_filepath, sheet_name='Results')
        logger.info(f"Successfully loaded results from {results_filepath}")
        
        # Convert assignment columns to appropriate format
        def process_assignment(x):
            try:
                # First try converting to float and then to int if it's a number
                return str(int(float(x)))
            except (ValueError, TypeError):
                # If not a number, return as string
                return str(x).strip() if pd.notna(x) else None
                
        # Process both assignment columns
        df_results['Assignment1'] = df_results['Assignment1'].apply(process_assignment)
        df_results['Assignment2'] = df_results['Assignment2'].apply(process_assignment)
        
    except Exception as e:
        logger.error(f"Error reading results file {results_filepath}: {e}")
        return
    
    result_list = []
    
    for idx, row in df_results.iterrows():
        assignment1 = row['Assignment1']
        assignment2 = row['Assignment2']
        
        # Skip if either assignment is None or NaN
        if pd.isna(assignment1) or pd.isna(assignment2):
            logger.warning(f"Skipping row {idx} due to missing assignment")
            continue
            
        pair = (assignment1, assignment2)
        logger.info(f"Processing pair: {pair}")
    
        combined_df, unique_B0, R20_mapping, R20_indices, df_ids = prepare_pair_data(assignments, pair)
        if combined_df is None:
            logger.warning(f"Could not prepare data for pair {pair}")
            continue
    
        # Extract parameters
        try:
            params = []
            params.append(float(row['kab']))
            params.append(float(row['kba']))
            params.append(float(row['Dw_ppm_df1']))
            params.append(float(row['Dw_ppm_df2']))
        
            for b0 in unique_B0:
                r20_df1_key = f'R20_{b0}_df1'
                params.append(float(row[r20_df1_key]))
        
            for b0 in unique_B0:
                r20_df2_key = f'R20_{b0}_df2'
                params.append(float(row[r20_df2_key]))
        
            params = np.array(params)
        except Exception as e:
            logger.error(f"Error extracting parameters for pair {pair}: {e}")
            continue
    
        # Check for NaNs in parameters
        if np.isnan(params).any():
            logger.warning(f"Parameters contain NaN for pair {pair}. Skipping.")
            continue
    
        result_dict = {
            'Assignment1': assignment1,
            'Assignment2': assignment2
        }
    
        # Map df_ids to Assign1 and Assign2 labels
        assign_labels = {0: 'Assign1', 1: 'Assign2'}
    
        # Initialize lists for overall metrics
        chi2_values = []
        r_squared_values = []
        total_residuals = []
        total_R2Eff_exp = []
        total_R2Eff_sim = []
        total_eR2Eff_exp = []
        total_num_points = 0
    
        # Loop over df_ids (0 and 1) and B0 values
        for df_id in [0, 1]:
            assign_label = assign_labels[df_id]
            for b0 in unique_B0:
                # Extract data for this assignment and B0
                mask = (combined_df['PairID'] == df_id) & (combined_df['B0'] == b0)
                df_subset = combined_df[mask]
                if df_subset.empty:
                    continue
    
                R2Eff_exp = df_subset['R2Eff'].values
                eR2Eff_exp = df_subset['eR2Eff'].values
                vcp = df_subset['Vcpmg'].values
                gammaB0 = df_subset['gammaB0'].values
                df_ids_subset = df_subset['PairID'].values
                R20_indices_subset = df_subset.apply(
                    lambda row: R20_mapping.get((row['B0'], row['PairID']), -1), axis=1).values
    
                # Compute predicted R2Eff
                R2Eff_sim = carver_richards_pair_numba(params, vcp, gammaB0, R20_indices_subset, df_ids_subset)
    
                # Compute residuals and metrics
                residuals = (R2Eff_exp - R2Eff_sim) / eR2Eff_exp
                chi2 = np.sum(residuals ** 2)
                dof = len(residuals) - len(params)
                chi2_reduced = chi2 / dof if dof > 0 else np.nan
    
                ss_res = np.sum((R2Eff_exp - R2Eff_sim) ** 2)
                ss_tot = np.sum((R2Eff_exp - np.mean(R2Eff_exp)) ** 2)
                r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else np.nan
    
                # Update tracking lists
                chi2_values.append(chi2)
                r_squared_values.append(r_squared)
                total_residuals.extend(residuals)
                total_R2Eff_exp.extend(R2Eff_exp)
                total_R2Eff_sim.extend(R2Eff_sim)
                total_eR2Eff_exp.extend(eR2Eff_exp)
                total_num_points += len(residuals)
    
                # Add individual B0 metrics to result_dict
                result_dict[f'chi2_B0_{b0}'] = chi2
                result_dict[f'reduced_chi2_B0_{b0}'] = chi2_reduced
                result_dict[f'R_squared_B0_{b0}'] = r_squared
    
        # Compute and add overall metrics
        if chi2_values and r_squared_values:
            chi2_overall = np.sum(chi2_values)
            total_dof = total_num_points - len(params)
            reduced_chi2_overall = chi2_overall / total_dof if total_dof > 0 else np.nan
    
            ss_res_total = np.sum((np.array(total_R2Eff_exp) - np.array(total_R2Eff_sim)) ** 2)
            ss_tot_total = np.sum((np.array(total_R2Eff_exp) - np.mean(total_R2Eff_exp)) ** 2)
            r_squared_overall = 1 - (ss_res_total / ss_tot_total) if ss_tot_total != 0 else np.nan
    
            result_dict.update({
                'chi2_overall': chi2_overall,
                'reduced_chi2_overall': reduced_chi2_overall,
                'R_squared_overall': r_squared_overall,
                'chi2_min': min(chi2_values),
                'chi2_max': max(chi2_values),
                'R_squared_min': min(r_squared_values),
                'R_squared_max': max(r_squared_values)
            })
        else:
            result_dict.update({
                'chi2_overall': np.nan,
                'reduced_chi2_overall': np.nan,
                'R_squared_overall': np.nan,
                'chi2_min': np.nan,
                'chi2_max': np.nan,
                'R_squared_min': np.nan,
                'R_squared_max': np.nan
            })
    
        result_list.append(result_dict)
    
    # Create DataFrame and save results
    if result_list:
        df_results_new = pd.DataFrame(result_list)
        try:
            with pd.ExcelWriter(results_filepath, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                df_results_new.to_excel(writer, index=False, sheet_name='Updated_Results')
                workbook = writer.book
                worksheet = writer.sheets['Updated_Results']
                
                # Apply number formatting
                for idx, column in enumerate(df_results_new.columns, 1):
                    if pd.api.types.is_numeric_dtype(df_results_new[column]):
                        for cell in worksheet.iter_cols(min_col=idx, max_col=idx, min_row=2):
                            for c in cell:
                                if not pd.isna(c.value):
                                    c.number_format = '0.0000'
            logger.info(f"Updated results saved to sheet 'Updated_Results' in {results_filepath}")
        except Exception as e:
            logger.error(f"Error saving updated results to Excel file: {e}")
    else:
        logger.warning("No results to save")

def combine_excel_sheets(excel_file):
    """
    Combines 'Results' and 'Updated_Results' sheets, adding kex and kex_err columns.
    Matches rows based on Assignment1 and Assignment2.
    
    Parameters:
    excel_file (str): Path to the Excel file
    
    Returns:
    pandas.DataFrame: Combined dataframe with all columns
    """
    import pandas as pd
    
    # Read both sheets
    df_results = pd.read_excel(excel_file, sheet_name='Results')
    df_updated = pd.read_excel(excel_file, sheet_name='Updated_Results')
    
    # Merge dataframes on Assignment1 and Assignment2
    combined_df = pd.merge(
        df_results, 
        df_updated,
        on=['Assignment1', 'Assignment2'],
        how='outer',
        suffixes=('', '_y')
    )
    
    # Calculate kex and kex_err from existing columns
    combined_df['kex'] = combined_df['kab'] + combined_df['kba']
    combined_df['kex_err'] = (
        (combined_df['kab_err']**2 + combined_df['kba_err']**2)**0.5
    )
    
    # Drop duplicate columns if they exist
    columns_to_drop = [col for col in combined_df.columns if col.endswith('_y')]
    combined_df = combined_df.drop(columns=columns_to_drop)
    
    # Save back to Excel with single sheet
    with pd.ExcelWriter(excel_file, engine='openpyxl', mode='w') as writer:
        combined_df.to_excel(writer, sheet_name='Results', index=False)
    
    return combined_df

def update_excel_main(excel_file):
    """
    Main function to process the Excel file
    """
    try:
        combined_df = combine_excel_sheets(excel_file)
        print(f"Successfully combined sheets and added kex columns in {excel_file}")
        return True
    except Exception as e:
        print(f"Error processing Excel file: {e}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Read Excel Pair Fit and Generate Pair Fitting Results.")
    parser.add_argument(
        '-i', '--userinput',
        type=str,
        default='UserInput.ini',
        help='Path to the UserInput.ini file.'
    )
    args = parser.parse_args()
    
    # Load user inputs
    config = configparser.ConfigParser()
    config.read(args.userinput)
    
    ProteinName = config.get('General', 'ProteinName', fallback=None)
    if not ProteinName:
        logger.error("ProteinName is missing in the [General] section of UserInput.ini.")
        sys.exit(1)
    
    # Construct the path to the '_all.xlsx' file
    excel_file = os.path.join(ProteinName, f'R2Eff_{ProteinName}_all.xlsx')
    if not os.path.exists(excel_file):
        logger.error(f"The combined Excel file '{excel_file}' does not exist.")
        sys.exit(1)
    
    # Get PairFit configurations
    save_plot = config.getboolean('PairFit', 'save_plot', fallback=False)
    save_plot_type = config.get('PairFit', 'save_plot_type', fallback='png')
    Chi2Plot = config.getboolean('PairFit', 'Chi2Plot', fallback=False)
    Chi2_PlotVar = config.get('PairFit', 'Chi2_PlotVar', fallback='kab')
    ComputeCores = config.getint('PairFit', 'ComputeCores', fallback=1)
    
    # Perform pair fitting and save results
    df_results = PairFitAndSave(
        excel_file, 
        save_plot=save_plot,  
        save_plot_type=save_plot_type,  # 'png' or 'pdf'
        Chi2Plot=Chi2Plot, 
        Chi2_PlotVar=Chi2_PlotVar,  # Change as needed
        ComputeCores=ComputeCores  # Select the number of cores as needed
    )

    # Compute R-squared and Chi-squared for each pair
    compute_rsquare_chi2(excel_file, 'pair_fit_results.xlsx')

    #  updates the Excel file:
    excel_file = os.path.join(ProteinName, 'pair_fit_results.xlsx')
    if os.path.exists(excel_file):
        # Call the new function to combine sheets and add kex columns
        success = update_excel_main(excel_file)
        if not success:
            print("Warning: Failed to update Excel file with combined sheets")
    else:
        print(f"Warning: Excel file {excel_file} not found")



