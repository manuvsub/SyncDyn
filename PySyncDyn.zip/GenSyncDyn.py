import subprocess
import sys
import os
import argparse
import configparser

def main():
    parser = argparse.ArgumentParser(description="Run GenR2Eff.py, PairFit.py, and PlotSyncDyn.py based on UserInput.ini.")
    parser.add_argument(
        '-i', '--userinput',
        type=str,
        default='UserInput.ini',
        help='Path to the UserInput.ini file.'
    )
    args = parser.parse_args()
    
    user_input = args.userinput
    if not os.path.isfile(user_input):
        print(f"Error: The UserInput.ini file '{user_input}' does not exist.")
        sys.exit(1)
    
    # Load user inputs with inline comment prefixes
    config = configparser.ConfigParser(inline_comment_prefixes=('#', ';'))
    config.read(user_input)
    
    # Get RunOptions configurations
    if 'RunOptions' not in config.sections():
        # If RunOptions section is missing, default to running all scripts
        run_genr2eff = True
        run_pairfit = True
        run_plotSyncDyn = True
    else:

        run_genr2eff = config.getboolean('RunOptions', 'run_GenR2Eff', fallback=True)
        run_pairfit = config.getboolean('RunOptions', 'run_PairFit', fallback=True)
        run_plotSyncDyn = config.getboolean('RunOptions', 'run_PlotSyncDyn', fallback=True)
    
    # Define the scripts and their corresponding arguments
    scripts = []
    if run_genr2eff:
        scripts.append( ('GenR2Eff.py', ['-i', user_input]) )
    if run_pairfit:
        scripts.append( ('PairFit.py', ['-i', user_input]) )
    if run_plotSyncDyn:
        scripts.append( ('PlotSyncDyn.py', ['-i', user_input]) )
    
    if not scripts:
        print("No scripts selected to run. Please enable at least one script in the [RunOptions] section of UserInput.ini.")
        sys.exit(0)
    
    for script, script_args in scripts:
        if not os.path.isfile(script):
            print(f"Error: The script '{script}' does not exist.")
            sys.exit(1)
        print(f"Running {script} with arguments {script_args}...")
        result = subprocess.run([sys.executable, script] + script_args)
        if result.returncode != 0:
            print(f"Error: {script} exited with return code {result.returncode}.")
            sys.exit(result.returncode)
        print(f"Completed {script} successfully.")
    
    print("All selected scripts executed successfully.")

if __name__ == "__main__":
    main()
