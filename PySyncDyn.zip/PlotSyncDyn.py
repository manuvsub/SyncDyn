import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import os
import sys
import re
from matplotlib.colors import LinearSegmentedColormap
import configparser
import argparse

# All the fonts are set to Arial
plt.rcParams['font.family'] = 'Arial'
# Editable in Illustrator
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42

# ------------------- Parameter->Math Variant Mapping -------------------
PARAMETER_LABELS = {
    'Chi2':               r'$\chi^2$',
    'Chi2_reduced':       r'$\chi^2_{\mathrm{red}}$',
    'R_squared':          r'$R^2$',
    'Chi2_overall':       r'$\chi^2_{\mathrm{overall}}$',
    'Chi2_reduced_overall': r'$\chi^2_{\mathrm{red,overall}}$',
    'R_squared_overall':  r'$R^2_{\mathrm{overall}}$',
    'Chi2_min':           r'$\chi^2_{\mathrm{min}}$',
    'Chi2_max':           r'$\chi^2_{\mathrm{max}}$',
    'R_squared_min':      r'$R^2_{\mathrm{min}}$',
    'R_squared_max':      r'$R^2_{\mathrm{max}}$'
}
# ----------------------------------------------------------------------

def GenColormap(Colors_Order, Colors_Value=None):
    """
    Generate a LinearSegmentedColormap based on the provided color order and values.
    
    Parameters:
    - Colors_Order (list of str): List of color names or hex codes in the desired order.
    - Colors_Value (list of float, optional): List of values corresponding to each color.
      Values must be in the range [0, 1]. If None, colors are equally spaced.
      
    Returns:
    - LinearSegmentedColormap: The generated colormap.
    """
    if Colors_Value is None:
        # Generate equally spaced values
        n = len(Colors_Order)
        Colors_Value = np.linspace(0, 1, n)
    return LinearSegmentedColormap.from_list('CustomMap', list(zip(Colors_Value, Colors_Order)))

def setup_font_sizes(FigSize_Inches):
    """
    Calculate font sizes relative to figure size.
    """
    base_factor = FigSize_Inches / 8.0
    title_size = max(min(16 * base_factor, 24), 14)
    label_size = max(min(14 * base_factor, 18), 12)
    tick_size = max(min(10 * base_factor, 14), 10)
    return base_factor, title_size, label_size, tick_size

def extract_numbers(assignment):
    """
    Extract residue number and methyl number from assignment string.
    Examples:
        'I135-CG2' -> (135, 2)
        'A109N-H'  -> (109, 0)
        'I135-CG1' -> (135, 1) 
    """
    numbers = [int(n) for n in re.findall(r'\d+', str(assignment))]
    if not numbers:
        return None, None
    elif len(numbers) == 1:
        return numbers[0], 0
    else:
        return numbers[0], numbers[1]

def atomindex2resnomethylno(atom_index, nucleus_type):
    """
    Convert atom_index to residue and methyl numbers, depending on nucleus_type.
    """
    if nucleus_type == '15N':
        return atom_index, 0
    elif nucleus_type == '13C':
        resno = ((atom_index-1) // 2) + 1
        methylno = (atom_index-1) % 2 + 1
        return resno, methylno

def calculate_atom_index(assignment, nucleus_type):
    """
    Calculate AtomIndex based on residue number and methyl number.
    """
    resno, methylno = extract_numbers(assignment)
    if resno is None:
        return np.nan
    if nucleus_type == '15N':
        return resno
    elif nucleus_type == '13C':
        return (resno - 1) * 2 + methylno
    return np.nan

def filter_by_region(atom_indices, region_range, atom_index_to_resno):
    """
    Filter atom_indices based on a provided region range in terms of residue numbers.
    """
    if region_range is None:
        return atom_indices
    return [
        idx for idx in atom_indices 
        if region_range[0] <= atom_index_to_resno[idx] <= region_range[1]
    ]

def plot_distribution_block(df,
                           PlotDistribution,
                           Dtbn_param,
                           Caxis,
                           Filter_Param,
                           FilterRange,
                           label_size,
                           tick_size,
                           title_size,
                           Parameter2Plot,
                           save_plot_type,
                           xlsxFile,
                           PlotContinuousResidueNumbers,
                           DtbnYlim=None,
                           DtbnXlim=None,
                           min_points_for_GMM=10,
                           min_sigma_fraction=0.02):
    """
    Plot the distribution of Dtbn_param values if PlotDistribution is True.

    Parameters:
        df (DataFrame):
            Input data (already filtered according to Parameter2Plot and Caxis).
        PlotDistribution (bool):
            Whether to plot the distribution or not.
        Dtbn_param (str):
            Name of the parameter to plot distribution for (e.g., 'kex', 'Pe').
        Caxis (tuple):
            Color axis range (applied to Parameter2Plot).
        Filter_Param (str):
            Parameter used for additional numeric filtering (e.g., 'kex').
        FilterRange (list):
            Range used for additional numeric filtering, e.g. [0, 5000].
        label_size (float):
            Font size for axis labels.
        tick_size (float):
            Font size for tick labels.
        title_size (float):
            Font size for the plot title.
        Parameter2Plot (str):
            Main parameter that was used to filter/create the matrix (used for filename).
        save_plot_type (str):
            File type to save plot (e.g., 'png', 'pdf', None for not saving).
        xlsxFile (str):
            Path to the original Excel file (used to derive save directory).
        PlotContinuousResidueNumbers (bool):
            Whether a 'full' range of residue numbers (atom indices) was plotted.
            Used to generate suffix in the saved filename.
        DtbnYlim (tuple, optional):
            Y-axis limits for the distribution histogram (e.g., (0, 50)).
            If None, matplotlib auto-scales.
        DtbnXlim (tuple, optional):
            X-axis limits for filtering the distribution data and for plotting (e.g., (0, 100)).
            If None, it is set automatically from the data min & max.
        min_points_for_GMM (int, optional):
            Minimum number of data points required to attempt a GMM fit.
        min_sigma_fraction (float, optional):
            **New**. If provided (e.g., 0.1), enforces a minimum standard deviation (\(\sigma\))
            for each Gaussian as (min_sigma_fraction * X_range), where X_range = DtbnXlim[1] - DtbnXlim[0].
            If None or 0, no minimum is enforced.

    Returns:
        None
    """
    if not PlotDistribution:
        return
    
    from sklearn.mixture import GaussianMixture
    from scipy.stats import norm
    
    # Build a symmetrical pivot table for the chosen Dtbn_param
    df_4Dtbn = df.pivot_table(index='atom_index1', columns='atom_index2', values=Dtbn_param, aggfunc='mean')
    # Mirror upper/lower triangles
    df_4Dtbn = df_4Dtbn.combine_first(df_4Dtbn.T)
    # Average them to ensure symmetry
    df_4Dtbn = (df_4Dtbn + df_4Dtbn.T) / 2
    
    print(f"Generating distribution for {Dtbn_param}...")

    # Get the lower-triangle (excluding diagonal) values
    mask = np.tril(np.ones_like(df_4Dtbn), k=-1).astype(bool)
    values = df_4Dtbn.values[mask]
    # Filter out NaNs
    values = values[~np.isnan(values)]
    
    # If user provided DtbnXlim, further filter the values
    if DtbnXlim is not None:
        values = values[(values >= DtbnXlim[0]) & (values <= DtbnXlim[1])]
    else:
        # Auto-scale from data if not provided
        DtbnXlim = (values.min(), values.max()) if len(values) > 0 else (0, 1)
    
    print(f"Number of data points after DtbnXlim filtering: {len(values)}")
    
    # Create the figure for the distribution
    plt.figure(figsize=(4, 3))
    plt.rcParams['font.family'] = 'Arial'
    plt.rcParams['font.size'] = tick_size

    # Decide on the bins for the histogram
    num_bins = 100
    bins = np.linspace(DtbnXlim[0], DtbnXlim[1], num_bins + 1)
    
    # Plot histogram
    counts, bins, _ = plt.hist(values, bins=bins, density=False,
                               alpha=0.7, label=f'Data (n={len(values)})',
                               color='gray')
    
    # Attempt GMM fitting if we have enough data
    if len(values) >= min_points_for_GMM:
        try:
            X = values.reshape(-1, 1)
            
            # Determine the maximum components based on sample size
            max_components = min(5, len(X))
            n_components_range = range(1, max_components + 1)
            bic = []
            
            # Find the optimal number of components by BIC
            for n_components in n_components_range:
                gmm = GaussianMixture(n_components=n_components, random_state=42)
                gmm.fit(X)
                bic.append(gmm.bic(X))
            
            optimal_n_components = n_components_range[np.argmin(bic)]
            print(f"Optimal number of Gaussian components: {optimal_n_components}")
            
            # Fit the optimal GMM
            gmm = GaussianMixture(n_components=optimal_n_components, random_state=42)
            gmm.fit(X)
            
            # Sort components by mean
            sort_idx = np.argsort(gmm.means_.flatten())
            means = gmm.means_.flatten()[sort_idx]
            weights = gmm.weights_[sort_idx]
            covars = gmm.covariances_.flatten()[sort_idx]  # variance for each component

            # --------------------------------------------------------------------
            # Enforce a minimum sigma if min_sigma_fraction is specified
            if min_sigma_fraction is not None and min_sigma_fraction > 0:
                x_range = DtbnXlim[1] - DtbnXlim[0]
                min_sigma = min_sigma_fraction * x_range
                # Clamp each component's variance if below (min_sigma)^2
                for i_comp in range(len(covars)):
                    current_sigma = np.sqrt(covars[i_comp])
                    if current_sigma < min_sigma:
                        covars[i_comp] = min_sigma**2
                print(f"Applied minimum sigma={min_sigma:.3f} based on fraction={min_sigma_fraction}")
            # --------------------------------------------------------------------

            # Scale factor to match histogram counts
            scale_factor = len(values) * (bins[1] - bins[0])
            
            # Points for plotting the fitted Gaussians
            x_fit = np.linspace(DtbnXlim[0], DtbnXlim[1], 200)
            
            colors = ['r', 'b', 'g', 'm', 'c']
            total_pdf = np.zeros_like(x_fit)
            
            # Plot individual Gaussians
            for i in range(optimal_n_components):
                pdf = weights[i] * norm.pdf(x_fit, means[i], np.sqrt(covars[i])) * scale_factor
                total_pdf += pdf
                plt.plot(x_fit, pdf, '--',
                         color=colors[i % len(colors)],
                         alpha=0.7,
                         label=f'Component {i+1}\n'
                               f'μ={means[i]:.2f}, '
                               f'σ={np.sqrt(covars[i]):.2f}, '
                               f'w={weights[i]:.2f}')
            
            # Plot total GMM PDF
            plt.plot(x_fit, total_pdf, 'k-', lw=2, label='Total fit')
        
        except Exception as e:
            print(f"Warning: Could not fit GMM: {str(e)}")
    else:
        print(f"Warning: Not enough data points ({len(values)}) to fit GMM "
              f"(minimum required: {min_points_for_GMM}).")
    
    # Set labels and title
    plt.xlabel(Dtbn_param, fontsize=label_size)
    plt.ylabel('Count', fontsize=label_size)
    plt.title(f'Distribution of {Dtbn_param}', fontsize=title_size)
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=tick_size)
    plt.grid(True, alpha=0.3)
    
    # Y-axis limit
    if DtbnYlim is not None:
        plt.ylim(DtbnYlim)
    else:
        # Leave some headroom above the tallest bar
        plt.ylim(0, max(counts) * 1.1 if len(counts) else 1)
    
    # Save figure if needed
    if save_plot_type:
        base_info = f"{Parameter2Plot}_Caxis{Caxis[0]}-{Caxis[1]}"
        filter_info = f"_{Filter_Param}{FilterRange[0]}-{FilterRange[1]}"
        continuous_suffix = "_full" if PlotContinuousResidueNumbers else ""
        
        # Include Dtbn_param in filename
        save_filename = os.path.join(
            os.path.dirname(xlsxFile),
            f'Dtbn_{Dtbn_param}_{base_info}{filter_info}{continuous_suffix}.{save_plot_type}'
        )
        plt.savefig(save_filename, format=save_plot_type, bbox_inches='tight')
        print(f"Distribution plot saved as {save_filename}")
    
    plt.close()

def calculate_dy_corr_score(pivot_filled, Caxis, atom_index_to_resno, residue_mapping, 
                           Parameter2Plot, Filter_Param, FilterRange, 
                           PlotContinuousResidueNumbers, save_plot_type, xlsxFile):
    """
    Calculate SyncDyn Score and optionally save to CSV.
    """
    total_residues = len(set(atom_index_to_resno.values()))
    CorrScore = {}
    for col in pivot_filled.columns:
        count_dict = pivot_filled[col][pivot_filled[col] >= Caxis[0]].count()
        count_dict -= 1  # remove diagonal value
        CorrScore[col] = count_dict / total_residues
    
    # Convert to DataFrame 
    CorrScore_df = pd.DataFrame.from_dict(CorrScore, orient='index', columns=['SyncDyn_Score'])
    CorrScore_df.index.name = 'Atom_Index'
    
    # Add Residue_Number and Residue_Name columns
    CorrScore_df['Residue_Number'] = CorrScore_df.index.map(atom_index_to_resno)
    CorrScore_df['Residue_Name'] = CorrScore_df.index.map(lambda x: residue_mapping.get(x, f"Res{atom_index_to_resno.get(x)}"))
    
    # Filter out rows with SyncDyn_Score < 0
    CorrScore_df = CorrScore_df[CorrScore_df['SyncDyn_Score'] > 0]
    
    # Reorder columns
    CorrScore_df = CorrScore_df[['Residue_Number', 'Residue_Name', 'SyncDyn_Score']]
    
    # Save score data if requested
    if save_plot_type:
        base_info = f"{Parameter2Plot}_Caxis{Caxis[0]}-{Caxis[1]}"
        filter_info = f"_kex{FilterRange[0]}-{FilterRange[1]}"
        continuous_suffix = "_full" if PlotContinuousResidueNumbers else ""
        base_filename = os.path.join(os.path.dirname(xlsxFile), 
                                     f'Score_{base_info}{filter_info}{continuous_suffix}')
        csv_filename = f"{base_filename}.csv"
        CorrScore_df.to_csv(csv_filename)
        print(f"Score data saved as {csv_filename}")

def setup_ticks(positions, atom_indices, TickStart_ResNo, TickInterval_ResNo,
                Tick_ShowResNumber, residue_mapping, atom_index_to_resno,
                nucleus_type, PlotContinuousResidueNumbers):
    major_ticks = []
    major_labels = []
    for i in range(len(positions)):
        if i >= TickStart_ResNo:
            if (i - TickStart_ResNo) % TickInterval_ResNo == 0:
                major_ticks.append(i)
                atom_idx = atom_indices[i]

                if Tick_ShowResNumber:
                    if nucleus_type == '13C' and PlotContinuousResidueNumbers:
                        label = str((atom_idx + 1) // 2)
                    else:
                        resno = atom_index_to_resno.get(atom_idx)
                        label = str(resno) if resno is not None else str(atom_idx)
                else:
                    label = residue_mapping.get(atom_idx, f"Idx{atom_idx}")

                major_labels.append(label)
    return major_ticks, major_labels

def PlotPairParameterNew(
    xlsxFile='PairFit_Results.xlsx',
    Parameter2Plot='R_squared_min',
    Colors_Order=None,
    Colors_Value=None,
    ColorMap=None,
    Caxis=(0.98, 1),
    PlotXRegionFromTo=None,
    PlotYRegionFromTo=None,
    save_plot_type=None,
    Show_CorrelationNumbers=True,
    PlotContinuousResidueNumbers=True,
    PlotContinuousResidueNumbers_FromTo=None,
    TickInterval_ResNo=1,
    TickStart_ResNo=1,
    Tick_ShowResNumber=True,
    MarkerType='s',
    MarkerSize_scale=0.5,
    ShowGrids=True,
    ShowGridsAvailableRes=True,
    Filter_Param='kex',
    FilterRange=[0, 5000],
    ShowFilteredPairs=True,
    FigSize_Inches=4,
    PlotDistribution=False,
    Dtbn_param='kex',
    DtbnYlim=None,  
    CorrelationNumbers_FontSize_Scale=1.0,
    SavePlotMatrixAsCSV=False,
    nucleus_type='15N',
    DtbnXlim=None  # New parameter
):
    """
    Plot pair parameter matrix with consistent labels for x and y axes.
    Now handles both 15N and 13C (methyl) data.
    """  

    # Setup font sizes
    base_factor, title_size, label_size, tick_size = setup_font_sizes(FigSize_Inches)

    # Setup colormap
    if Colors_Order is not None:
        colormap = LinearSegmentedColormap.from_list(
            'CustomMap', list(zip(Colors_Value or np.linspace(0, 1, len(Colors_Order)), Colors_Order))
        )
    else:
        colormap = ColorMap or LinearSegmentedColormap.from_list('WhiteRed', ['white', 'red'])

    # Verify and load Excel data
    if not os.path.isfile(xlsxFile):
        raise FileNotFoundError(f"File not found: {xlsxFile}")

    try:
        df = pd.read_excel(xlsxFile, sheet_name='Results')
    except Exception as e:
        raise Exception(f"Error reading Excel file: {e}")

    # Apply filtering if Filter_Param and FilterRange are provided
    if Filter_Param and FilterRange and Filter_Param in df.columns:
        df = df[(df[Filter_Param] >= FilterRange[0]) & (df[Filter_Param] <= FilterRange[1])]
        if df.empty:
            raise ValueError(f"No data points remain after filtering {Filter_Param}")

    # Verify required columns
    required_columns = {'Assignment1', 'Assignment2', Parameter2Plot}
    if not required_columns.issubset(df.columns):
        raise ValueError(f"Missing columns: {required_columns - set(df.columns)}")

    # Create unified assignment mapping with AtomIndex
    all_assignments = pd.concat([
        df['Assignment1'].rename('assignment'),
        df['Assignment2'].rename('assignment')
    ]).drop_duplicates()

    all_assignments_df = pd.DataFrame({
        'assignment': all_assignments,
        'resno': all_assignments.apply(lambda x: extract_numbers(x)[0]),
        'methylno': all_assignments.apply(lambda x: extract_numbers(x)[1]),
        'atom_index': all_assignments.apply(lambda x: calculate_atom_index(x, nucleus_type)),
        'available': True
    }).dropna()


    # -- Existing code that reads PlotContinuousResidueNumbers_FromTo --
    if PlotContinuousResidueNumbers and (PlotContinuousResidueNumbers_FromTo is not None):
        fromVal, toVal = PlotContinuousResidueNumbers_FromTo

        # For 13C, multiply residue boundaries by 2:
        if nucleus_type == '13C':
            fromVal *= 2
            toVal   *= 2

        # Build a set of all needed indices in this range
        needed_indices = set(range(fromVal, toVal + 1))

        # Compare with what all_assignments_df already has
        current_indices = set(all_assignments_df['atom_index'])
        missing_indices = needed_indices - current_indices

        # Generate rows for any missing indices
        missing_data = []
        for idx in missing_indices:
            resno, methylno = atomindex2resnomethylno(idx, nucleus_type)
            missing_data.append({
                'atom_index': idx,
                'resno': resno,
                'methylno': methylno,
                'assignment': resno,   # or build a custom string
                'available': False
            })

        if missing_data:
            missing_df = pd.DataFrame(missing_data)
            all_assignments_df = pd.concat([all_assignments_df, missing_df], ignore_index=True)


    # Fill missing indices
    if not all_assignments_df.empty:
        max_index = max(all_assignments_df['atom_index']) 
        print(f"Max index: {max_index}")
    else:
        max_index = 0
        print("No assignments available after initial processing.")

    all_indices = set(range(max_index + 1))
    missing_indices = all_indices - set(all_assignments_df['atom_index'])

    missing_data = []
    for idx in missing_indices:
        resno, methylno = atomindex2resnomethylno(idx, nucleus_type)
        missing_data.append({
            'atom_index': idx,
            'resno': resno,
            'methylno': methylno,
            'assignment': resno,
            'available': False
        })

    if missing_data:
        missing_df = pd.DataFrame(missing_data)
        all_assignments_df = pd.concat([all_assignments_df, missing_df], ignore_index=True)

    residue_mapping = all_assignments_df.set_index('atom_index')['assignment'].to_dict()
    atom_index_to_resno = all_assignments_df.set_index('atom_index')['resno'].to_dict()

    # Map atom indices
    df['atom_index1'] = df['Assignment1'].apply(lambda x: calculate_atom_index(x, nucleus_type))
    df['atom_index2'] = df['Assignment2'].apply(lambda x: calculate_atom_index(x, nucleus_type))

    plot_param = Parameter2Plot 
    colorbar_label = PARAMETER_LABELS.get(Parameter2Plot, Parameter2Plot)

    # Filter by Caxis range on Parameter2Plot
    df = df[(df[Parameter2Plot] >= Caxis[0]) & (df[Parameter2Plot] <= Caxis[1])]

    # Check if DataFrame is empty after filtering
    if df.empty:
        print(f"Warning: No data remains after filtering {Parameter2Plot} by range {Caxis}. A blank matrix will be plotted.")


    # Get atom index range
    all_atom_indices = sorted(set(df['atom_index1']).union(set(df['atom_index2'])))
    if not all_atom_indices:
        print("Warning: No atom indices found after filtering. Proceeding with an empty matrix.")

    if PlotContinuousResidueNumbers and not ShowFilteredPairs:
        if all_atom_indices:
            min_idx = 1
            max_idx = max(all_atom_indices)
            all_atom_indices = list(range(min_idx, max_idx + 1))
        else:
            all_atom_indices = []


    # Minimal change below:
    if PlotContinuousResidueNumbers and (PlotContinuousResidueNumbers_FromTo is not None): 
        fromVal, toVal =  PlotContinuousResidueNumbers_FromTo
        if nucleus_type == '13C':
            # Double the integer boundaries
            fromVal *= 2
            toVal   *= 2
        all_atom_indices = list(range(fromVal, toVal + 1))


    # Filter by region
    x_indices = filter_by_region(all_atom_indices, PlotXRegionFromTo, atom_index_to_resno)
    y_indices = filter_by_region(all_atom_indices, PlotYRegionFromTo, atom_index_to_resno)

    # Create and process correlation matrix
    pivot = df.pivot_table(index='atom_index1', columns='atom_index2', 
                           values=plot_param, aggfunc='mean')
    pivot = pivot.reindex(index=y_indices, columns=x_indices)

    pivot_filled = pivot.combine_first(pivot.T)
    pivot_filled = (pivot_filled + pivot_filled.T) / 2

    # Fill diagonal
    if PlotContinuousResidueNumbers and not ShowFilteredPairs:
        for i, atom_idx in enumerate(y_indices):
            pivot_filled.iloc[i, i] = 0.99 if atom_idx in residue_mapping else np.nan
    else:
        np.fill_diagonal(pivot_filled.values, 0.99)
    pivot_filled = pivot_filled.mask(pivot_filled > 0.99, 0.99)

    available_dict = all_assignments_df.set_index('atom_index')['available'].to_dict()
    for i, atom_idx_i in enumerate(y_indices):
        for j, atom_idx_j in enumerate(x_indices):
            if i == j:
                pivot_filled.iloc[i, j] = 0.99 if available_dict.get(atom_idx_i, False) else np.nan
    pivot_filled = pivot_filled.mask(pivot_filled > 0.99, 0.99)

    # Plot distribution if requested
    plot_distribution_block(
        df, PlotDistribution, Dtbn_param, Caxis, Filter_Param, FilterRange, 
        label_size, tick_size, title_size, Parameter2Plot, 
        save_plot_type, xlsxFile, PlotContinuousResidueNumbers,
        DtbnYlim=DtbnYlim,   
        DtbnXlim=DtbnXlim     
    )

    # Calculate SyncDyn Score
    calculate_dy_corr_score(
        pivot_filled, Caxis, atom_index_to_resno, residue_mapping, 
        Parameter2Plot, Filter_Param, FilterRange, 
        PlotContinuousResidueNumbers, save_plot_type, xlsxFile
    )
 
    # Create plot
    fig = plt.figure(figsize=(FigSize_Inches * 1.2, FigSize_Inches * 1.2))
    ax = fig.add_subplot(111, aspect='equal')

    # Convert matrix to scatter plot format
    x_coords = []
    y_coords = []
    values = []
    annotations = []

    for i in range(len(pivot_filled)):
        for j in range(len(pivot_filled)):
            val = pivot_filled.iloc[i, j]
            if pd.notnull(val) and val >= Caxis[0]:
                x_coords.append(j)
                y_coords.append(i)
                values.append(val)
                if Show_CorrelationNumbers:
                    annotations.append(f"{int(round(val * 100))}")
                else:
                    annotations.append("")

    # Calculate marker size (unchanged)
    points_per_inch = 72
    figure_points = FigSize_Inches * points_per_inch
    n_rows = len(pivot_filled)
    points_per_cell = figure_points / n_rows
    marker_size = (points_per_cell * 0.8) ** 2
    marker_size = marker_size * MarkerSize_scale

    # Sort and plot points
    sort_idx = np.argsort(values)
    x_coords_sorted = np.array(x_coords)[sort_idx]
    y_coords_sorted = np.array(y_coords)[sort_idx]
    values_sorted = np.array(values)[sort_idx]
    annotations_sorted = np.array(annotations)[sort_idx]

    scatter = ax.scatter(
        x_coords_sorted, y_coords_sorted, c=values_sorted, 
        cmap=colormap, vmin=Caxis[0], vmax=Caxis[1], 
        marker=MarkerType, s=marker_size
    )

    # Draw numeric annotations if Show_CorrelationNumbers=True 
    for i, txt in enumerate(annotations_sorted):
        x_pt = x_coords_sorted[i]
        y_pt = y_coords_sorted[i] 
        if txt and x_pt != y_pt:  # Skip diagonal if necessary
            ax.text(
                x_pt, y_pt, txt,
                ha='center', va='center',
                fontsize=tick_size * CorrelationNumbers_FontSize_Scale,
                color='black'
            ) 


    # Add colorbar
    value_range = np.abs(Caxis[1] - Caxis[0])
    tick_interval = 0.05 if value_range <= 0.1 else 0.1 
    cbar = plt.colorbar(
        scatter, fraction=0.046, pad=0.0075, shrink=0.5, aspect=20,  # Reduced pad from 0.04 to 0.01
        anchor=(0, 1), panchor=(0, 1),
        ticks=np.arange(Caxis[0], Caxis[1] + tick_interval, tick_interval)
    )
    cbar.ax.tick_params(labelsize=tick_size)
    cbar.ax.set_ylabel(colorbar_label, rotation=270, labelpad=30, fontsize=label_size)

    # Rotate colorbar tick labels by 90 degrees
    for label in cbar.ax.get_yticklabels():
        label.set_rotation(-90)

    if nucleus_type == '13C' and PlotContinuousResidueNumbers:
        TickInterval_ResNo = TickInterval_ResNo * 2

    # Setup axis ticks
    major_x_ticks, major_x_labels = setup_ticks(
        range(len(x_indices)), x_indices,
        TickStart_ResNo, TickInterval_ResNo, Tick_ShowResNumber,
        residue_mapping, atom_index_to_resno, nucleus_type, PlotContinuousResidueNumbers
    )
    major_y_ticks, major_y_labels = setup_ticks(
        range(len(y_indices)), y_indices,
        TickStart_ResNo, TickInterval_ResNo, Tick_ShowResNumber,
        residue_mapping, atom_index_to_resno, nucleus_type, PlotContinuousResidueNumbers
    )

    ax.set_xticks(major_x_ticks)
    ax.set_xticklabels(major_x_labels, rotation=90)
    ax.set_yticks(major_y_ticks)
    ax.set_yticklabels(major_y_labels, rotation=0)

    # Configure grids
    if ShowGrids:
        if ShowGridsAvailableRes:
            available_x = sorted(set(x_coords))
            available_y = sorted(set(y_coords))
            for x in available_x:
                ax.axvline(x=x, color='gray', linestyle='-', alpha=0.2, linewidth=0.5)
            for y in available_y:
                ax.axhline(y=y, color='gray', linestyle='-', alpha=0.2, linewidth=0.5)
        else:
            all_x = np.arange(0, len(x_indices), 1)
            all_y = np.arange(0, len(y_indices), 1)
            for x in all_x:
                ax.axvline(x=x, color='gray', linestyle='-', alpha=0.2, linewidth=0.5)
            for y in all_y:
                ax.axhline(y=y, color='gray', linestyle='-', alpha=0.2, linewidth=0.5)

    # Final plot settings
    title = f'{colorbar_label} Matrix'
    if Filter_Param and FilterRange:
        title += f'  ({Filter_Param}: {FilterRange[0]} to {FilterRange[1]})'
    plt.title(title, fontsize=title_size, pad=20)
    plt.xlabel('Residue', fontsize=label_size)
    plt.ylabel('Residue', fontsize=label_size)

    # Set axis limits with padding
    padding = 0.01
    x_range = len(x_indices)
    y_range = len(y_indices)
    x_pad = x_range * padding
    y_pad = y_range * padding
    ax.set_xlim(-0.5 - x_pad, len(x_indices)-0.5 + x_pad)
    ax.set_ylim(len(y_indices)-0.5 + y_pad, -0.5 - y_pad)

    plt.gca().invert_yaxis()


    # Save plot and matrix if requested
    if save_plot_type:
        base_info = f"{Parameter2Plot}_Caxis{Caxis[0]}-{Caxis[1]}"
        filter_info = f"_kex{FilterRange[0]}-{FilterRange[1]}"
        continuous_suffix = "_full" if PlotContinuousResidueNumbers else ""
        base_filename = os.path.join(
            os.path.dirname(xlsxFile), 
            f'Matrix_{base_info}{filter_info}{continuous_suffix}'
        )
        
        plot_filename = f"{base_filename}.{save_plot_type}"
        plt.savefig(plot_filename, format=save_plot_type, bbox_inches='tight')
        print(f"Plot saved as {plot_filename}")
        
        if SavePlotMatrixAsCSV:
            matrix_to_save = pivot_filled.copy()
            matrix_to_save.index = [
                residue_mapping.get(idx, f"Res{atom_index_to_resno.get(idx)}") 
                for idx in y_indices
            ]
            matrix_to_save.columns = [
                residue_mapping.get(idx, f"Res{atom_index_to_resno.get(idx)}")
                for idx in x_indices
            ]
            matrix_to_save.to_csv(f"{base_filename}.csv")
            print(f"Matrix data saved as {base_filename}.csv")

    return fig

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plot Dynamic Correlation based on UserInput.ini.")
    parser.add_argument(
        '-i', '--userinput',
        type=str,
        default='RNaseA_full.ini',
        help='Path to the UserInput.ini file.'
    )
    args = parser.parse_args()
    
    # Load user inputs
    config = configparser.ConfigParser()
    config.read(args.userinput)
    
    ProteinName = config.get('General', 'ProteinName', fallback=None)
    if not ProteinName:
        print("Error: ProteinName is missing in the [General] section of UserInput.ini.")
        sys.exit(1)
    
    # Construct the path to the 'pair_fit_results.xlsx' file
    excel_file = os.path.join(ProteinName, 'pair_fit_results.xlsx')
    if not os.path.exists(excel_file):
        print(f"Error: The Excel file '{excel_file}' does not exist.")
        sys.exit(1)
    
    # Get PlotSyncDyn configurations
    plot_dy_corr_config = config['PlotSyncDyn']

    Parameter2Plot = plot_dy_corr_config.get('Parameter2Plot', 'R_squared_min')
    Colors_Order = [color.strip() for color in plot_dy_corr_config.get('Colors_Order', '').split(',') if color.strip()]
    Colors_Value = [float(val.strip()) for val in plot_dy_corr_config.get('Colors_Value', '').split(',') if val.strip()]
    ColorMap = plot_dy_corr_config.get('ColorMap', None)

    Show_CorrelationNumbers = plot_dy_corr_config.getboolean('Show_CorrelationNumbers', True)
    PlotContinuousResidueNumbers = plot_dy_corr_config.getboolean('PlotContinuousResidueNumbers', True)    
    PlotContinuousResidueNumbers_FromTo = [int(val.strip()) for val in plot_dy_corr_config.get('PlotContinuousResidueNumbers_FromTo', '').split(',') if val.strip()]
    
    TickInterval_ResNo = plot_dy_corr_config.getint('TickInterval_ResNo', 5)
    TickStart_ResNo = plot_dy_corr_config.getint('TickStart_ResNo', 5)
    Tick_ShowResNumber = plot_dy_corr_config.getboolean('Tick_ShowResNumber', True)

    Filter_Param = plot_dy_corr_config.get('Filter_Param', 'kex')
    FilterRange = [int(val.strip()) for val in plot_dy_corr_config.get('FilterRange', '0,5000').split(',') if val.strip()]
    ShowFilteredPairs = plot_dy_corr_config.getboolean('ShowFilteredPairs', True)
    FigSize_Inches = plot_dy_corr_config.getfloat('FigSize_Inches', 4)

    MarkerType = plot_dy_corr_config.get('MarkerType', 's')
    MarkerSize_scale = plot_dy_corr_config.getfloat('MarkerSize_scale', 0.5)

    ShowGrids = plot_dy_corr_config.getboolean('ShowGrids', True)
    ShowGridsAvailableRes = plot_dy_corr_config.getboolean('ShowGridsAvailableRes', True)

    PlotDistribution = plot_dy_corr_config.getboolean('PlotDistribution', False)
    Dtbn_param = plot_dy_corr_config.get('Dtbn_param', 'kex')
    
    # Parse DtbnYlim
    dtbn_ylim_str = plot_dy_corr_config.get('DtbnYlim', None)
    DtbnYlim = None
    if dtbn_ylim_str:
        try:
            # Split and handle potential spaces around the comma
            ylim_values = [x.strip() for x in dtbn_ylim_str.split(',')]
            DtbnYlim = tuple(float(x) for x in ylim_values)
            if len(DtbnYlim) != 2:
                print("Warning: DtbnYlim should have exactly 2 values. Using default auto-scaling.")
                DtbnYlim = None
        except ValueError:
            print("Warning: Could not parse DtbnYlim values. Using default auto-scaling.")
            DtbnYlim = None

    # Parse DtbnXlim
    dtbn_xlim_str = plot_dy_corr_config.get('DtbnXlim', None)
    DtbnXlim = None
    if dtbn_xlim_str:
        try:
            # Split and handle potential spaces around the comma
            xlim_values = [x.strip() for x in dtbn_xlim_str.split(',')]
            DtbnXlim = tuple(float(x) for x in xlim_values)
            if len(DtbnXlim) != 2:
                print("Warning: DtbnXlim should have exactly 2 values. Using default based on data.")
                DtbnXlim = None
        except ValueError:
            print("Warning: Could not parse DtbnXlim values. Using default based on data.")
            DtbnXlim = None

    CorrelationNumbers_FontSize_Scale = plot_dy_corr_config.getfloat('CorrelationNumbers_FontSize_Scale', 1.0)
    SavePlotMatrixAsCSV = plot_dy_corr_config.getboolean('SavePlotMatrixAsCSV', False)

    nucleus_type = config.get('General', 'Nucleus', fallback='15N')

    if ColorMap == 'None':
        ColorMap = None
    Caxis = [float(val.strip()) for val in plot_dy_corr_config.get('Caxis', '0,1').split(',') if val.strip()]
    plotx = plot_dy_corr_config.get('PlotXRegionFromTo', None)
    if plotx:
        PlotXRegionFromTo = tuple(int(x) for x in plotx.split(','))
    else:
        PlotXRegionFromTo = None
    ploty = plot_dy_corr_config.get('PlotYRegionFromTo', None)
    if ploty:
        PlotYRegionFromTo = tuple(int(y) for y in ploty.split(','))
    else:
        PlotYRegionFromTo = None

    save_plot_type = plot_dy_corr_config.get('save_plot_type', None)
    if save_plot_type:
        save_plot_type = save_plot_type.strip().lower()

    if PlotContinuousResidueNumbers_FromTo:
        if nucleus_type != '13C':
            TickStart_ResNo = TickStart_ResNo - PlotContinuousResidueNumbers_FromTo[0] 
        else:
            TickStart_ResNo = (TickStart_ResNo - PlotContinuousResidueNumbers_FromTo[0]) * 2

    # Call PlotPairParameterNew
    PlotPairParameterNew(
        xlsxFile=excel_file,
        Parameter2Plot=Parameter2Plot,
        Colors_Order=Colors_Order if Colors_Order else None,
        Colors_Value=Colors_Value if Colors_Value else None,
        ColorMap=ColorMap,
        Caxis=tuple(Caxis) if Caxis else (0,1),
        PlotXRegionFromTo=PlotXRegionFromTo,
        PlotYRegionFromTo=PlotYRegionFromTo,
        save_plot_type=save_plot_type,
        Show_CorrelationNumbers=Show_CorrelationNumbers,
        PlotContinuousResidueNumbers=PlotContinuousResidueNumbers,
        PlotContinuousResidueNumbers_FromTo=PlotContinuousResidueNumbers_FromTo,
        TickInterval_ResNo=TickInterval_ResNo,
        TickStart_ResNo=TickStart_ResNo,
        Tick_ShowResNumber=Tick_ShowResNumber,
        MarkerType=MarkerType,
        MarkerSize_scale=MarkerSize_scale,
        ShowGrids=ShowGrids,
        ShowGridsAvailableRes=ShowGridsAvailableRes,
        Filter_Param=Filter_Param,
        FilterRange=FilterRange,
        ShowFilteredPairs=ShowFilteredPairs,
        FigSize_Inches=FigSize_Inches,
        PlotDistribution=PlotDistribution,
        Dtbn_param=Dtbn_param,
        DtbnYlim=DtbnYlim,
        CorrelationNumbers_FontSize_Scale=CorrelationNumbers_FontSize_Scale,
        SavePlotMatrixAsCSV=SavePlotMatrixAsCSV,
        nucleus_type=nucleus_type,
        DtbnXlim=DtbnXlim  # Pass the new parameter
    )
