import pandas as pd
import re
import os
import numpy as np 
from scipy.interpolate import interp1d 
import matplotlib.pyplot as plt
import math
import configparser
import argparse
import sys

def read_list_file(filename):
    """
    Reads a list file with specified columns, processes it, and returns a pandas DataFrame.

    Parameters:
    - filename: str, path to the input file.

    Returns:
    - df: pandas DataFrame containing the processed data.
    """
    possible_columns = [
        'Assignment', 'User', 'w1', 'w2', 'w1 (Hz)', 'w2 (Hz)', 
        'Dev w1', 'Dev w2', 'Volume', 'Volume Error', 'Trans-Volume', 
        'Fit RMS %', 'Fit Height', 'Data Height', 'S/N', 'lw1 (hz)', 
        'lw2 (hz)', 'Freq', 'Dev', 'Spectrum', 'Distance', 
        'ATOM1', 'ATOM2', 'INTENSITY', 'ERROR', 'NOTE', 'Note'
    ]
    
    string_columns = [
        'Assignment', 'User', 'Spectrum', 'Distance', 
        'ATOM1', 'ATOM2', 'NOTE', 'Note'
    ]
    
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
        
        header_line = None
        header_index = None
        
        for idx, line in enumerate(lines):
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                if stripped.startswith('"') and stripped.endswith('"'):
                    stripped = stripped[1:-1].strip()
                header_line = stripped
                header_index = idx
                break
        
        if header_line is None:
            raise ValueError("No header line found in the file.")
        
        columns = re.split(r'\s{2,}', header_line)
        columns = [col.replace(' ', '_') for col in columns]
        possible_columns_underscored = [col.replace(' ', '_') for col in possible_columns]
        
        df = pd.read_fwf(
            filename,
            header=None,
            names=columns,
            skiprows=header_index + 1,
            skip_blank_lines=True,
            comment='#'
        )
        
        df = df.loc[:, df.columns.isin(possible_columns_underscored)]
        
        string_cols_present = [
            col.replace(' ', '_') for col in string_columns 
            if col.replace(' ', '_') in df.columns
        ]
        
        for col in string_cols_present:
            df[col] = df[col].astype(str)
        
        numeric_cols = [col for col in df.columns if col not in string_cols_present]
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
        return df
    
    except Exception as e:
        print(f"Error reading the file {filename}: {e}")
        return pd.DataFrame()


def process_files(list_folder, list_files, vcpmg):
    """
    Processes each file in the list, reads it, adds Vcpmg, and stores in a dictionary.

    Parameters:
    - list_folder: str, path to the folder containing the files.
    - list_files: list of str, filenames to process.
    - vcpmg: list of int, Vcpmg values corresponding to each file.

    Returns:
    - dict_of_dfs: dict, keys are filenames and values are processed DataFrames.
    """
    dict_of_dfs = {}
    
    for idx, file_name in enumerate(list_files):
        file_path = os.path.join(list_folder, file_name)
        df = read_list_file(file_path)
        
        if not df.empty:
            if idx < len(vcpmg):
                df['Vcpmg'] = vcpmg[idx]
            else:
                df['Vcpmg'] = None
            
            assignment_col = 'Assignment'
            if assignment_col in df.columns:
                df.set_index(assignment_col, inplace=True)
            else:
                print(f"Warning: '{assignment_col}' column not found in {file_name}.")
            
            dict_of_dfs[file_name] = df
            print(f"Successfully read {file_name} with Vcpmg = {vcpmg[idx] if idx < len(vcpmg) else 'N/A'}")
        else:
            print(f"Skipped {file_name} due to read errors or empty data.")
    
    return dict_of_dfs


def create_assignment_dict(dict_of_dfs):
    """
    Creates a dictionary of DataFrames indexed by Assignment.

    Parameters:
    - dict_of_dfs: dict, keys are filenames and values are DataFrames.

    Returns:
    - assignment_dict: dict, keys are assignments and values are aggregated DataFrames.
    """
    required_columns = ['Vcpmg', 'Data_Height']
    optional_columns = ['S/N']
    
    assignment_dict = {}
    
    for file_name, df in dict_of_dfs.items():
        has_sn = 'S/N' in df.columns
        required = required_columns + (optional_columns if has_sn else [])
        
        for assignment, row in df.iterrows():
            if assignment not in assignment_dict:
                cols = ['Vcpmg', 'Data_Height'] + (['S/N'] if has_sn else [])
                assignment_dict[assignment] = pd.DataFrame(columns=cols)
            
            data = {
                'Vcpmg': row['Vcpmg'],
                'Data_Height': row['Data_Height']
            }
            if has_sn:
                data['S/N'] = row.get('S/N', None)
            
            new_row = pd.DataFrame([data])
            assignment_dict[assignment] = pd.concat(
                [assignment_dict[assignment], new_row],
                ignore_index=True
            )
    
    return assignment_dict


def calculate_r2eff(assignment_dict, tcpmg_ms, B0):
    """
    Calculates R2Eff and its error for each assignment using error propagation,
    adds a B0 column, and skips assignments with invalid or missing reference intensity.

    Parameters:
    - assignment_dict: dict, keys are assignments and values are DataFrames
    - tcpmg_ms: float, CPMG total time in ms
    - B0: numeric, the B0 value to add as a column

    Returns:
    - assignment_dict: dict, updated with B0, R2Eff, and eR2Eff calculations
    """
    assignments_to_remove = []
    
    for assignment, df in assignment_dict.items():
        # Check for required columns
        # required_columns = ['Vcpmg', 'Data_Height', 'S/N']
        # if not all(col in df.columns for col in required_columns):
        #     print(f"Skipping assignment '{assignment}' due to missing required columns.")
        #     assignments_to_remove.append(assignment)
        #     continue
        
        # Extract reference intensity where Vcpmg == 0
        I0_data = df[df['Vcpmg'] == 0]
        if I0_data.empty:
            print(f"Skipping assignment '{assignment}' due to missing reference intensity (Vcpmg=0).")
            assignments_to_remove.append(assignment)
            continue
        
        I0 = I0_data['Data_Height'].iloc[0]
        I0_SN = I0_data['S/N'].iloc[0]
        
        if I0 <= 0 or I0_SN <= 0:
            print(f"Skipping assignment '{assignment}' due to invalid reference intensity or S/N.")
            assignments_to_remove.append(assignment)
            continue
        
        # Calculate relative errors
        eI0_rel = 1 / I0_SN
        eI_rel = 1 / df['S/N']
        
        # Calculate R2Eff
        I = df['Data_Height']
        t = tcpmg_ms * 1e-3  # Convert to seconds
        # if dtype of I is object, convert to float
        if I.dtype == 'O':
            I = I.astype(float)
        if eI_rel.dtype == 'O':
            eI_rel = eI_rel.astype(float)

        df['R2Eff'] = -np.log(I / I0) / t
        
        # Error propagation for R2Eff
        df['eR2Eff'] = np.sqrt(eI_rel**2 + eI0_rel**2) / t
        
        # Add B0 column with the same value for all rows
        df['B0'] = B0
        
        # Filter out the reference point (Vcpmg == 0) and reset index
        df = df[df['Vcpmg'] != 0].reset_index(drop=True)
        
        # Reorder the columns to: B0, Vcpmg, R2Eff, eR2Eff
        df = df[['B0', 'Vcpmg', 'R2Eff', 'eR2Eff']]
        
        # Update the assignment dictionary
        assignment_dict[assignment] = df
        print(f"Calculated R2Eff, eR2Eff, and added B0 for '{assignment}'")
    
    # Remove assignments with invalid or missing reference intensity
    for assignment in assignments_to_remove:
        del assignment_dict[assignment]
        print(f"Removed assignment '{assignment}' from the dataset.")
    
    return assignment_dict



def calculate_r2eff_errors(assignment_dict):
    """
    Calculates the error in R2Eff from repeated data.
    """
    for assignment, df in assignment_dict.items():
        if df.empty:
            continue
        
        # Store B0 value before processing
        B0_value = df['B0'].iloc[0]
        
        df['Vcpmg'] = df['Vcpmg'].round(2)
        vcpmg_counts = df['Vcpmg'].value_counts()
        repeated_vcpmg = vcpmg_counts[vcpmg_counts > 1].index.tolist()
        
        if repeated_vcpmg:
            repeated_stats = df[df['Vcpmg'].isin(repeated_vcpmg)].groupby('Vcpmg')['R2Eff'].agg(['mean', 'max', 'min']).reset_index()
            repeated_stats['eR2Eff'] = (repeated_stats['max'] - repeated_stats['min']) / 2
            repeated_summary = repeated_stats[['Vcpmg', 'mean', 'eR2Eff']].rename(columns={'mean': 'R2Eff'})
        else:
            repeated_summary = pd.DataFrame(columns=['Vcpmg', 'R2Eff', 'eR2Eff'])
        
        unique_df = df[~df['Vcpmg'].isin(repeated_vcpmg)].copy()
        unique_df['eR2Eff'] = np.nan
        
        summarized_df = pd.concat([repeated_summary, unique_df[['Vcpmg', 'R2Eff', 'eR2Eff']]], ignore_index=True)
        summarized_df.sort_values('Vcpmg', inplace=True)
        summarized_df.reset_index(drop=True, inplace=True)
        
        # Add B0 column back
        summarized_df['B0'] = B0_value
        
        known = summarized_df[summarized_df['eR2Eff'].notna()]
        unknown = summarized_df[summarized_df['eR2Eff'].isna()]
        
        # Convert datatypes to float
        for df_ in [known, unknown]:
            for col in ['Vcpmg', 'R2Eff', 'eR2Eff']:
                if df_[col].dtype == 'O':
                    df_[col] = df_[col].astype(float)
        
        if not known.empty and not unknown.empty:
            interp_func = interp1d(
                known['Vcpmg'],
                known['eR2Eff'],
                kind='linear',
                fill_value='extrapolate',
                bounds_error=False
            )
            summarized_df.loc[summarized_df['eR2Eff'].isna(), 'eR2Eff'] = interp_func(unknown['Vcpmg'])
        
        summarized_df['eR2Eff'] = summarized_df['eR2Eff'].clip(lower=0)
        summarized_df['eR2Eff'].fillna(summarized_df['eR2Eff'].median(), inplace=True)
        
        # Include B0 in the final DataFrame
        final_df = summarized_df[['B0', 'Vcpmg', 'R2Eff', 'eR2Eff']].copy()
        assignment_dict[assignment] = final_df
    
    return assignment_dict


def plot_r2eff_errors(assignment_dict, plots_per_figure=16, figsize=(20, 20)):
    """
    Generates scatter plots of Vcpmg vs R2Eff with error bars for each assignment.

    Parameters:
    - assignment_dict: dict, keys are assignments and values are DataFrames with 'Vcpmg', 'R2Eff', 'eR2Eff'.
    - plots_per_figure: int, number of subplots per figure window.
    - figsize: tuple, size of each figure window.
    """
    total_assignments = len(assignment_dict)
    total_figures = math.ceil(total_assignments / plots_per_figure)
    assignment_names = list(assignment_dict.keys())
    
    for fig_num in range(total_figures):
        fig, axes = plt.subplots(4, 4, figsize=figsize)
        fig.suptitle(f'Vcpmg vs R2Eff with Error Bars (Figure {fig_num + 1})', fontsize=16)
        axes_flat = axes.flatten()
        
        for i in range(plots_per_figure):
            assignment_index = fig_num * plots_per_figure + i
            if assignment_index >= total_assignments:
                axes_flat[i].axis('off')
                continue
            
            assignment = assignment_names[assignment_index]
            df = assignment_dict[assignment]
            
            axes_flat[i].errorbar(
                df['Vcpmg'],
                df['R2Eff'],
                yerr=df['eR2Eff'],
                fmt='o',
                ecolor='red',
                capsize=3,
                markersize=5,
                label='R2Eff'
            )
            axes_flat[i].set_title(assignment)
            axes_flat[i].set_xlabel('Vcpmg')
            axes_flat[i].set_ylabel('R2Eff')
            axes_flat[i].grid(True)
            axes_flat[i].legend()
        
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.show()


def sanitize_sheet_name(name, existing_names):
    """
    Sanitizes the sheet name by removing invalid characters and ensuring uniqueness.

    Parameters:
    - name: Original sheet name.
    - existing_names: set, already used sheet names to ensure uniqueness.

    Returns:
    - safe_name: Sanitized and unique sheet name.
    """
    invalid_chars = ['\\', '/', '*', '?', ':', '[', ']']
    for char in invalid_chars:
        name = name.replace(char, '_')
    
    name = name[:31]
    
    original_name = name
    counter = 1
    while name in existing_names:
        suffix = f"_{counter}"
        name = f"{original_name[:31 - len(suffix)]}{suffix}"
        counter += 1
    
    return name


def save_to_excel(assignment_dict, output_path):
    """
    Saves the assignment dictionary to an Excel workbook with multiple sheets.

    Parameters:
    - assignment_dict: dict, keys are assignments and values are DataFrames.
    - output_path: str, path to the output Excel file.
    """
    with pd.ExcelWriter(output_path, engine='xlsxwriter') as writer:
        existing_sheet_names = set()
        
        for sheet_name, df in assignment_dict.items():
            prefixed_name = f"Assign_{sheet_name}"
            safe_sheet_name = sanitize_sheet_name(prefixed_name, existing_sheet_names)
            existing_sheet_names.add(safe_sheet_name)
            df.to_excel(writer, sheet_name=safe_sheet_name, index=True)


def load_XL2assignment_dict(output_path):
    """
    Loads the output Excel file and recreates the assignment_dict in the same format.

    Parameters:
    - output_path: str, path to the output Excel file.

    Returns:
    - assignment_dict: dict, keys are assignments and values are DataFrames.
    """
    try:
        # Check if the file exists
        if not os.path.exists(output_path):
            raise FileNotFoundError(f"The file {output_path} does not exist.")

        # Read all sheets from the Excel file
        xls = pd.ExcelFile(output_path)
        assignment_dict = {}
        
        for sheet_name in xls.sheet_names:
            # Assuming sheet names are prefixed with 'Assign_'
            if sheet_name.startswith('Assign_'):
                assignment = sheet_name[len('Assign_'):]
            else:
                assignment = sheet_name  # If no prefix, use the sheet name as is
            
            # Read the sheet into a DataFrame
            df = pd.read_excel(xls, sheet_name=sheet_name, index_col=0)
            
            # Ensure the DataFrame has the expected columns
            expected_columns = {'Vcpmg', 'R2Eff', 'eR2Eff'}
            missing_columns = expected_columns - set(df.columns)
            if missing_columns:
                print(f"Warning: Missing columns {missing_columns} in sheet '{sheet_name}'.")
            
            # Convert columns to numeric types where applicable
            for col in ['Vcpmg', 'R2Eff', 'eR2Eff']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Store the DataFrame in the dictionary
            assignment_dict[assignment] = df.reset_index(drop=True)
        
        print(f"Successfully loaded {len(assignment_dict)} assignments from {output_path}.")
        return assignment_dict
    
    except Exception as e:
        print(f"Error loading the file {output_path}: {e}")
        return {}


def combine_excel_sheets(excel_savePaths, ProteinName):
    """
    Combines Excel sheets with matching sheet names from multiple Excel files by concatenating them.
    Saves the combined data into a new Excel file named 'R2Eff_{ProteinName}_all.xlsx'.

    Parameters:
    - excel_savePaths: list of str, paths to the Excel files to be combined.
    - ProteinName: str, name of the protein for naming the combined file.

    Returns:
    - None
    """
    if not excel_savePaths:
        print("No Excel file paths provided.")
        return

    combined_sheets = {}

    for file_path in excel_savePaths:
        try:
            xls = pd.ExcelFile(file_path)
            for sheet in xls.sheet_names:
                df = pd.read_excel(xls, sheet_name=sheet)
                if sheet in combined_sheets:
                    combined_sheets[sheet] = pd.concat([combined_sheets[sheet], df], ignore_index=True)
                else:
                    combined_sheets[sheet] = df.copy()
        except Exception as e:
            print(f"Error processing file {file_path}: {e}")

    # Ensure the output directory exists
    output_dir = ProteinName
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    output_filename = os.path.join(output_dir, f'R2Eff_{ProteinName}_all.xlsx')
    with pd.ExcelWriter(output_filename, engine='xlsxwriter') as writer:
        existing_sheet_names = set()
        invalid_chars = ['\\', '/', '*', '?', ':', '[', ']']
        
        for sheet_name, df in combined_sheets.items():
            # Sanitize sheet name
            safe_name = sheet_name
            for char in invalid_chars:
                safe_name = safe_name.replace(char, '_')
            safe_name = safe_name[:31]  # Excel sheet name limit

            # Ensure uniqueness
            original_name = safe_name
            counter = 1
            while safe_name in existing_sheet_names:
                suffix = f"_{counter}"
                safe_name = f"{original_name[:31 - len(suffix)]}{suffix}"
                counter += 1
            existing_sheet_names.add(safe_name)

            # Write to Excel
            df.to_excel(writer, sheet_name=safe_name, index=False)

    print(f"Combined Excel file saved as '{output_filename}'.")


def load_user_input(user_input_path):
    """
    Loads user input from an INI file.

    Parameters:
    - user_input_path: str, path to the UserInput.ini file.

    Returns:
    - ProteinName: str, name of the protein.
    - ExptlDict: dict, experimental configurations.
    """
    try:
        config = configparser.ConfigParser()
        config.read(user_input_path)
        
        if 'General' not in config.sections():
            raise ValueError("Missing [General] section in the UserInput.ini file.")
        
        ProteinName = config.get('General', 'ProteinName', fallback=None)
        if not ProteinName:
            raise ValueError("ProteinName is missing in the [General] section of UserInput.ini.")
        
        ExptlDict = {}
        for section in config.sections():
            if section == 'General':
                continue
            list_folder = config.get(section, 'list_folder', fallback=None)
            list_files = config.get(section, 'list_files', fallback='')
            vcpmg = config.get(section, 'vcpmg', fallback='')
            tcpmg_ms = config.get(section, 'tcpmg_ms', fallback=None)
            
            if not all([list_folder, list_files, vcpmg, tcpmg_ms]):
                print(f"Warning: Missing one or more keys in section [{section}]. Skipping this section.")
                continue
            
            # Parse list_files and vcpmg
            list_files = [file.strip() for file in list_files.split(',') if file.strip()]
            vcpmg = [int(v.strip()) for v in vcpmg.split(',') if v.strip().isdigit()]
            tcpmg_ms = float(tcpmg_ms)
            
            ExptlDict[section] = {
                'list_folder': list_folder,
                'list_files': list_files,
                'vcpmg': vcpmg,
                'tcpmg_ms': tcpmg_ms
            }
        
        if not ExptlDict:
            raise ValueError("No valid experimental configurations found in UserInput.ini.")
        
        return ProteinName, ExptlDict

    except Exception as e:
        print(f"Error loading user input from {user_input_path}: {e}")
        sys.exit(1)


def main(user_input_path):
    # Load user inputs
    ProteinName, ExptlDict = load_user_input(user_input_path)

    excel_savePaths = []
    # Iterate over the ExptlDict
    for B0, exptl_dict in ExptlDict.items():

        list_folder = exptl_dict['list_folder']
        list_files = exptl_dict['list_files']
        vcpmg = exptl_dict['vcpmg']
        tcpmg_ms = exptl_dict['tcpmg_ms'] 
    
        # Process Files
        dict_of_dfs = process_files(list_folder, list_files, vcpmg)
        
        # Create Assignment Dictionary
        assignment_dict = create_assignment_dict(dict_of_dfs)
        
        # Calculate R2Eff
        assignment_dict = calculate_r2eff(assignment_dict, tcpmg_ms, B0)

        # # # # Calculate R2Eff Errors
        # assignment_dict = calculate_r2eff_errors(assignment_dict) 

        # Save to Excel 
        # Create a folder with ProteinName to save the combined excel files
        if not os.path.exists(ProteinName):
            os.makedirs(ProteinName)
        output_excel_path  = os.path.join(ProteinName, f'R2Eff_{ProteinName}_{B0}.xlsx')
        save_to_excel(assignment_dict, output_excel_path)
        print(f"\nAll data has been successfully saved to {output_excel_path}.")

        excel_savePaths.append(output_excel_path)

    # Combine all Excel files
    combine_excel_sheets(excel_savePaths, ProteinName)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process R2Eff data based on UserInput.ini.")
    parser.add_argument(
        '-i', '--input',
        type=str,
        default=  'UserInput.ini', #'PKA_atpgn_Methyl.ini',#
        help='Path to the UserInput.ini file.'
    )
    args = parser.parse_args()
    main(args.input)
