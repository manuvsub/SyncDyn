import os
import sys
import pymol
from pymol import cmd
import pandas as pd
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
import configparser

def create_custom_colormap(colors_order, colors_value):
    return LinearSegmentedColormap.from_list('custom', list(zip(colors_value, colors_order)))

def map_score_to_color(score, cmap, min_score, max_score):
    if min_score == max_score:
        return cmap(0)[:3]
    else:
        normalized_score = (score - min_score) / (max_score - min_score)
        return cmap(normalized_score)[:3]

def parse_view_matrix(view_string):
    if not view_string:
        return None
    clean_string = view_string.replace('\\', '').replace('(', '').replace(')', '')
    return tuple(float(x.strip()) for x in clean_string.split(',') if x.strip())

def visualize_SyncDyn(config_file):
    config = configparser.ConfigParser()
    config.read(config_file)
    
    # Parse config sections
    score_file = config['General']['ScoreFile']
    pdb_id = config['General']['pdb']
    
    view_matrix = parse_view_matrix(config['PyMolView'].get('SetView', ''))
    
    label_options = {
        'show': config['LabelOptions'].getboolean('show', False),
        'color': config['LabelOptions'].get('color', 'black'),
        'size': float(config['LabelOptions'].get('size', '12')),
        'offset': list(map(float, config['LabelOptions'].get('offset', '1.5,0,0').split(','))),
        'background': config['LabelOptions'].getboolean('background', True)
    }

    ray_options = {
        'size': tuple(map(int, config['RayOptions'].get('size', '1000,1000').split(','))),
        'shadows': int(config['RayOptions'].get('shadows', '0')),
        'trace_mode': int(config['RayOptions'].get('trace_mode', '1'))
    }
    
    visual_options = {
        'sphere_size': float(config['VisualOptions'].get('sphere_size', '1.0')),
        'cartoon_transparency': float(config['VisualOptions'].get('cartoon_transparency', '0.5')),
        'sphere_transparency': float(config['VisualOptions'].get('sphere_transparency', '0.0')),
        'cartoon_color': config['VisualOptions'].get('cartoon_color', 'white')
    }
    
    colors = {
        'order': config['SphereColors'].get('ColorOrder', 'white,red,black').split(','),
        'value': list(map(float, config['SphereColors'].get('ColorValue', '0,0.5,1').split(',')))
    }

    # Initialize PyMOL
    os.environ.update({
        'PYMOL_QUIET': '1',
        'PYMOL_THREAD': '0',
        'PYGAME_HIDE_SUPPORT_PROMPT': '1'
    })

    if os.uname().machine == 'arm64':
        os.environ['PYMOL_DEV'] = '1'
    
    pymol.finish_launching(['pymol', '-qc'])
    
    # Load data
    df = pd.read_csv(score_file)
    cmd.load(f"{pdb_id}.pdb") if os.path.exists(f"{pdb_id}.pdb") else cmd.fetch(pdb_id)
    
    # Basic structure setup
    cmd.show_as("cartoon")
    cmd.color(visual_options['cartoon_color'])
    cmd.cartoon("loop", "all")
    cmd.set("cartoon_transparency", visual_options['cartoon_transparency'])
    
    # Publication quality settings
    cmd.set("ray_shadows", ray_options['shadows'])
    cmd.set("ray_trace_mode", ray_options['trace_mode'])
    cmd.set("ray_trace_color", "black")
    cmd.set("ray_trace_frames", 1)
    cmd.set("depth_cue", 0)
    cmd.set("antialias", 2)
    cmd.set("hash_max", 300)
    cmd.set("spec_reflect", 0.5)
    cmd.set("spec_power", 50)
    cmd.set("ambient", 0.4)
    cmd.set("direct", 0.6)
    cmd.set("ray_opaque_background", 0)
    
    # Label settings
    cmd.set("label_font_id", 7)
    cmd.set("label_size", label_options['size'])
    cmd.set("label_position", label_options['offset'])
    cmd.set("float_labels", 1)
    
    cmd.bg_color("white")
    
    # Create visualization
    cmap = create_custom_colormap(colors['order'], colors['value'])
    min_score = df['SyncDyn_Score'].min()
    max_score = df['SyncDyn_Score'].max()

    # Check for valid 'Residue_Number' entries before creating spheres and labels
    if 'Residue_Number' in df.columns:
        # Filter out invalid or empty entries
        valid_residues = df['Residue_Number'].dropna().astype(str).str.strip()
        valid_residues = [res for res in valid_residues if res]

        if valid_residues:
            cmd.select("n_atoms", "name N and resi " + "+".join(valid_residues))
            cmd.show("spheres", "n_atoms")
            cmd.set("sphere_scale", visual_options['sphere_size'])
            cmd.set("sphere_transparency", visual_options['sphere_transparency'])

            if label_options['show']:
                cmd.set("label_color", label_options['color'])
                if label_options['background']:
                    cmd.set("label_outline_color", "white")
                    cmd.set("label_outline", 1)

            for _, row in df.iterrows():
                res_num = str(row['Residue_Number']).strip()
                # Proceed only if residue number is valid
                if res_num:
                    rgb = map_score_to_color(row['SyncDyn_Score'], cmap, min_score, max_score)
                    cmd.set_color(f"color_{res_num}", rgb)
                    cmd.color(f"color_{res_num}", f"n_atoms and resi {res_num}")

                    if label_options['show']:
                        cmd.label(f"n_atoms and resi {res_num}", f"'{res_num}'")
        else:
            print("Residue_Number column exists but contains no valid entries. Skipping sphere visualization.")
    else:
        print("No 'Residue_Number' column found in CSV. Skipping sphere visualization.")
    
    if view_matrix:
        cmd.set_view(view_matrix)
    else:
        cmd.zoom("all")
        cmd.center("all")
    
    # Save output
    output_base = os.path.splitext(score_file)[0] + "_pymol"
    cmd.ray(*ray_options['size'])
    cmd.save(f"{output_base}.pse")
    cmd.png(f"{output_base}.png", ray=1, width=ray_options['size'][0], height=ray_options['size'][1])
    
    print(f"Visualization completed. Saved PSE and PNG files")
    cmd.quit()

if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] != '-i':
        print("Usage: python Corr2Pymol.py -i config.ini")
        sys.exit(1)
    visualize_SyncDyn(sys.argv[2])
